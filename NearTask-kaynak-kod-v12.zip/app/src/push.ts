import type { Api, Notice } from "./types";

export type PushState = "unsupported" | "denied" | "on" | "off";

export function pushState(): PushState {
  if (!("Notification" in window)) return "unsupported";
  if (Notification.permission === "denied") return "denied";
  return Notification.permission === "granted" ? "on" : "off";
}

function b64ToBytes(b64: string) {
  const pad = "=".repeat((4 - (b64.length % 4)) % 4);
  const raw = atob((b64 + pad).replace(/-/g, "+").replace(/_/g, "/"));
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
}

let lastError = "";
/** Why the last attempt to register this phone failed (empty if it worked). */
export function pushError() { return lastError; }

function key(): string | undefined { return (import.meta as any).env?.VITE_VAPID_PUBLIC_KEY; }

async function swReady(): Promise<ServiceWorkerRegistration> {
  const existing = await navigator.serviceWorker.getRegistration();
  if (!existing) await navigator.serviceWorker.register("./sw.js");
  return await Promise.race([
    navigator.serviceWorker.ready,
    new Promise<never>((_, no) => setTimeout(() => no(new Error("service worker not ready")), 8000)),
  ]);
}

/** In live mode "on" means this phone is really registered, not only that permission was given. */
export async function pushStatus(api: Api): Promise<PushState> {
  const st = pushState();
  if (st !== "on" || api.mode !== "live" || !key() || !("serviceWorker" in navigator)) return st;
  try {
    const reg = await navigator.serviceWorker.getRegistration();
    return (await reg?.pushManager.getSubscription()) ? "on" : "off";
  } catch { return "off"; }
}

/** Ask for permission; in live mode also register this phone for push messages while the app is closed. */
export async function enablePush(api: Api): Promise<PushState> {
  lastError = "";
  if (!("Notification" in window)) return "unsupported";
  let perm: NotificationPermission = Notification.permission;
  try { if (perm === "default") perm = await Notification.requestPermission(); } catch { return "unsupported"; }
  if (perm !== "granted") return perm === "denied" ? "denied" : "off";
  const k = key();
  if (api.mode !== "live" || !k || !api.savePush) return "on";
  if (!("serviceWorker" in navigator) || !("PushManager" in window)) { lastError = "push not supported here"; return "unsupported"; }
  try {
    const reg = await swReady();
    let sub = await reg.pushManager.getSubscription();
    // A subscription made with an older key cannot receive messages: replace it.
    const want = b64ToBytes(k).join(",");
    const has = sub?.options?.applicationServerKey ? new Uint8Array(sub.options.applicationServerKey).join(",") : want;
    if (sub && has !== want) { await sub.unsubscribe(); sub = null; }
    if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToBytes(k) });
    await api.savePush(sub.toJSON());
    return "on";
  } catch (e: any) {
    lastError = String(e?.message || e || "unknown error");
    return "off";
  }
}

/** While the app is open in the background, show a system notification. */
export function showLocal(n: Notice) {
  if (!("Notification" in window) || Notification.permission !== "granted" || !document.hidden) return;
  try {
    const note = new Notification(n.title, { body: n.body, icon: "icon.svg", tag: n.id });
    note.onclick = () => { window.focus(); location.hash = n.link; note.close(); };
  } catch {}
}
