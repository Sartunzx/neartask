# NearTask

Local shifts and home services around Keynsham, Bristol and Bath. A product of Artwin Ltd.

Live: https://alitekincelik-lang.github.io/neartask/

- Repo root: the live site served by GitHub Pages (`index.html`, `sw.js`, `manifest.webmanifest`, icons)
- `app/`: source code (React + TypeScript + Supabase). See `app/README.md` for setup and how to rebuild the live site.
