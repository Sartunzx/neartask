import type { Filters, Listing } from "./types";
import { km, locate } from "./geo";

export function today(offset = 0): string {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}

export function daysFromToday(date: string): number {
  const a = new Date();
  a.setHours(0, 0, 0, 0);
  const b = new Date(date + "T00:00");
  return Math.round((b.getTime() - a.getTime()) / 864e5);
}

export type WhenLabel = "past" | "today" | "tomorrow" | "week" | "later";
export function whenOf(date: string): WhenLabel {
  const n = daysFromToday(date);
  return n < 0 ? "past" : n === 0 ? "today" : n === 1 ? "tomorrow" : n <= 7 ? "week" : "later";
}

/** Shared client-side filter, used by demo mode and as a final pass in live mode. */
export function applyFilters(list: Listing[], f: Filters): Listing[] {
  const q = f.q.trim().toLowerCase();
  const out = list.filter((l) => {
    if (l.status !== "open" || daysFromToday(l.date) < 0) return false;
    if (f.kind !== "all" && l.kind !== f.kind) return false;
    if (f.category !== "all" && l.category !== f.category) return false;
    if (f.when !== "any") {
      const n = daysFromToday(l.date);
      if (f.when === "today" && n !== 0) return false;
      if (f.when === "tomorrow" && n !== 1) return false;
      if (f.when === "week" && n > 7) return false;
    }
    if (q && !(l.title + " " + l.area + " " + l.description + " " + (l.owner?.name || "")).toLowerCase().includes(q)) return false;
    return true;
  });
  if (f.near) {
    for (const l of out) {
      const p = l.lat != null && l.lng != null ? { lat: l.lat, lng: l.lng } : locate(l.area);
      l.distance = p ? km(f.near, p) : undefined;
    }
  }
  const soon = (a: Listing, b: Listing) => (a.date + (a.start_time || "")).localeCompare(b.date + (b.start_time || ""));
  out.sort((a, b) =>
    f.sort === "new" ? b.created_at.localeCompare(a.created_at)
    : f.sort === "near" ? (a.distance ?? 999) - (b.distance ?? 999) || soon(a, b)
    : soon(a, b)
  );
  return out;
}

export function uid(): string {
  return (crypto as any).randomUUID ? crypto.randomUUID() : "id" + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export function lsGet<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
export function lsSet(key: string, v: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(v));
  } catch {}
}

/** Resize a photo in the browser before upload (max 1280px, JPEG). */
export function shrinkImage(file: File, max = 1280): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const s = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * s);
      c.height = Math.round(img.height * s);
      c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      c.toBlob((b) => (b ? resolve(b) : reject(new Error("image"))), "image/jpeg", 0.82);
    };
    img.onerror = () => reject(new Error("image"));
    img.src = url;
  });
}

export function blobToDataUrl(b: Blob): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result));
    r.onerror = rej;
    r.readAsDataURL(b);
  });
}
