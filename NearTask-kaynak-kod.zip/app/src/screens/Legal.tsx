import { COMPANY } from "../company";
import { TopBar } from "../ui";

const who = () =>
  `${COMPANY.name}${COMPANY.number ? `, a company registered in England and Wales (company number ${COMPANY.number})` : ""}${COMPANY.address ? `, registered office ${COMPANY.address}` : ""}`;

function Doc({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="screen legal">
      <TopBar title={title} backTo="/me" />
      <article className="doc">
        <h1>{title}</h1>
        <p className="mute xs">Last updated {COMPANY.updated}</p>
        {children}
        <p className="mute xs">Questions? Email <b>{COMPANY.email}</b>.</p>
      </article>
    </div>
  );
}

export function Privacy() {
  return (
    <Doc title="Privacy Policy">
      <p>NearTask is run by {who()} ("we", "us"). We are the data controller for personal data processed through NearTask{COMPANY.ico ? ` and are registered with the Information Commissioner's Office (ICO) under number ${COMPANY.ico}` : ""}. This policy explains what we collect, why, and your rights under UK data protection law (UK GDPR and the Data Protection Act 2018).</p>

      <h2>What we collect</h2>
      <ul>
        <li><b>Account details:</b> email address and an encrypted password.</li>
        <li><b>Profile:</b> name or business name, postcode district, photo or logo, short bio, skills and the days you're available, if you add them.</li>
        <li><b>Listings:</b> job or task details, pay, date and time, area, photos, and the exact address, which we only show to the person you accept.</li>
        <li><b>Activity:</b> applications, invites, messages, reviews, saved listings, alerts, reports and blocks.</li>
        <li><b>Approximate location:</b> the centre point of your postcode district, used to sort by distance. If you tap "Use my location", your device location is used on your phone for that search and is not stored.</li>
        <li><b>Technical data:</b> basic logs (such as IP address and device type) kept by our hosting providers for security.</li>
      </ul>

      <h2>Why we use it (and our lawful basis)</h2>
      <ul>
        <li>To run the service you sign up for: showing listings, connecting people, messaging and notifications (<i>contract</i>).</li>
        <li>To keep NearTask safe: preventing fraud, reviewing reports, suspending accounts that break our rules (<i>legitimate interests</i>).</li>
        <li>To meet legal obligations, for example responding to lawful requests (<i>legal obligation</i>).</li>
        <li>To send phone notifications, only if you turn them on (<i>consent</i>, which you can withdraw in your phone settings).</li>
      </ul>
      <p>We don't sell your data and we don't use it for advertising.</p>

      <h2>Who can see what</h2>
      <ul>
        <li>Your profile name, photo, area, bio, skills, rating and reviews are visible to other users.</li>
        <li>Messages are only visible to the two people in the conversation.</li>
        <li>A listing's exact address is only visible to its owner and to people the owner accepts.</li>
        <li>Our admins can see reports and take action on accounts and listings.</li>
      </ul>

      <h2>Service providers</h2>
      <p>We use Supabase (database, sign-in and file storage, hosted in the EU) and GitHub Pages (website hosting). Maps use OpenStreetMap and postcode lookups use postcodes.io. These providers process data only to run their service for us. Where data is transferred outside the UK, it is protected by appropriate safeguards such as UK adequacy regulations or standard contractual clauses.</p>

      <h2>How long we keep it</h2>
      <p>We keep your data while your account is open. If you delete your account, we delete your profile, listings, applications, messages and photos straight away. Backups are overwritten within 30 days. We may keep a record of a suspension if needed to stop repeat abuse.</p>

      <h2>Your rights</h2>
      <p>You can access, correct, download or delete your data, object to or restrict how we use it, and withdraw consent. You can edit your profile and delete your account in the app at any time (Profile → Delete account). For anything else, email {COMPANY.email}. You can also complain to the ICO at ico.org.uk.</p>

      <h2>Children</h2>
      <p>NearTask is for people aged 16 and over. Jobs may have higher age limits set by the employer.</p>

      <h2>Changes</h2>
      <p>If we make important changes we'll tell you in the app.</p>
    </Doc>
  );
}

export function Terms() {
  return (
    <Doc title="Terms of Use">
      <p>These terms are an agreement between you and {who()}, which runs NearTask. By creating an account you agree to them.</p>

      <h2>What NearTask is</h2>
      <p>NearTask is a noticeboard that connects people and businesses for local shifts and home services. We are not an employer or an employment agency, and we are not a party to any agreement you make with another user. Pay, hours, safety and the quality of work are between you and the other person.</p>

      <h2>Your account</h2>
      <ul>
        <li>You must be 16 or over and give accurate information.</li>
        <li>Keep your password safe. You're responsible for what happens on your account.</li>
        <li>One person or business per account. Don't impersonate anyone.</li>
      </ul>

      <h2>Zero tolerance for abuse</h2>
      <p>There is no place on NearTask for objectionable content or abusive users. You must not post or send anything that is:</p>
      <ul>
        <li>harassing, hateful, threatening, sexual or violent;</li>
        <li>discriminatory on grounds such as race, religion, sex, sexual orientation, disability or age;</li>
        <li>fraudulent or misleading, including fake jobs or asking anyone to pay to apply;</li>
        <li>illegal, including work for people who don't have the right to work in the UK.</li>
      </ul>
      <p>You can report listings and people, and block anyone. We review reports within 24 hours and will remove content and suspend accounts that break these rules, without notice.</p>

      <h2>Businesses posting jobs</h2>
      <ul>
        <li>You're responsible for following employment law, including right-to-work checks, the National Minimum Wage, health and safety and any tax obligations.</li>
        <li>Listings must describe real work with honest pay.</li>
      </ul>

      <h2>People doing work</h2>
      <p>Check every listing yourself, meet in public where possible and never pay money to apply for a job. If something doesn't feel right, report it.</p>

      <h2>Reviews</h2>
      <p>Reviews must be honest and based on real work done through NearTask.</p>

      <h2>Your content</h2>
      <p>You keep ownership of what you post. You give us permission to display it in NearTask so the service works.</p>

      <h2>Our responsibility</h2>
      <p>We provide NearTask "as is" and can't guarantee it will always be available or error-free. We are not liable for the actions of users or for agreements between users. Nothing in these terms limits liability that can't be limited by law, such as for death or personal injury caused by negligence, or your rights as a consumer.</p>

      <h2>Ending your account</h2>
      <p>You can delete your account at any time in the app. We may suspend or close accounts that break these terms.</p>

      <h2>Law</h2>
      <p>These terms are governed by the law of England and Wales.</p>
    </Doc>
  );
}
