import { useEffect, useState } from "react";
import { useApp, type Theme } from "../state";
import { Avatar, Empty, Icon, ListingCard, Loading, Logo, Sheet, Stars, TopBar, useLoad } from "../ui";
import { fmtAgo, fmtDate, type Key } from "../i18n";
import { isOffensive } from "../moderation";
import { lsSet } from "../util";
import { COMPANY } from "../company";
import { CATEGORIES, DAYS, type Listing, type ProfileInput } from "../types";
import { PushToggle } from "./Extra";
import { locate } from "../geo";

export function Login({ next }: { next: string }) {
  const { api, t, go, uid } = useApp();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [type, setType] = useState<"business" | "person">("person");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [agree, setAgree] = useState(false);
  const [err, setErr] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (uid) go(next || "/", true); }, [uid, next, go]);

  const explain = (x: any) => {
    const m = String(x?.message || "");
    const map: Record<string, Key> = { exists: "exists", unconfirmed: "unconfirmed", wrong: "wrongLogin", rate: "errRate", network: "errNetwork", weak: "errWeak", short: "shortPw" };
    if (map[m]) return t(map[m]);
    if (m.startsWith("other:") && m.length > 6) return m.slice(6);
    return t("error");
  };
  const submit = async () => {
    setErr(""); setInfo("");
    const e = email.trim().toLowerCase();
    if (mode === "up" && !name.trim()) return setErr(t("required", { f: type === "business" ? t("yourNameBiz") : t("yourNamePerson") }));
    if (!/^\S+@\S+\.\S+$/.test(e)) return setErr(t("badEmail"));
    if (pw.length < 6) return setErr(t("shortPw"));
    if (mode === "up" && !agree) return setErr(t("mustAgree"));
    if (mode === "up" && isOffensive(name)) return setErr(t("offensive"));
    setBusy(true);
    try {
      if (mode === "up") {
        lsSet("nt_pending_profile", { name: name.trim().slice(0, 60), account_type: type });
        const r = await api.signUp(e, pw);
        if (r === "confirm") { setInfo(t("confirmSent", { email: e })); setMode("in"); }
      } else await api.signIn(e, pw);
    } catch (x) { setErr(explain(x)); } finally { setBusy(false); }
  };
  const forgot = async () => {
    setErr(""); setInfo("");
    const e = email.trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(e)) return setErr(t("badEmail"));
    try { await api.resetPassword(e); setInfo(t("resetSent")); } catch (x) { setErr(explain(x)); }
  };
  const typeBtn = (v: "business" | "person", title: Key, sub: Key, icon: string) => (
    <button type="button" className={"kindbtn" + (type === v ? " on" : "")} aria-pressed={type === v} onClick={() => setType(v)}>
      <Icon name={icon} size={22} /><b>{t(title)}</b><small>{t(sub)}</small>
    </button>
  );
  return (
    <div className="screen login">
      <TopBar backTo="/" />
      <div className="login-head"><Logo size={56} /><h1>{mode === "in" ? t("signInTitle") : t("register")}</h1></div>
      <div className="seg">
        <button className={mode === "in" ? "on" : ""} onClick={() => { setMode("in"); setErr(""); }}>{t("login")}</button>
        <button className={mode === "up" ? "on" : ""} onClick={() => { setMode("up"); setErr(""); }}>{t("register")}</button>
      </div>
      <form onSubmit={(e) => { e.preventDefault(); submit(); }}>
        {mode === "up" && (<>
          <span className="lbl">{t("iAm")}</span>
          <div className="duo tight">{typeBtn("person", "asPerson", "asPersonSub", "user")}{typeBtn("business", "asBusiness", "asBusinessSub", "briefcase")}</div>
          <label>{type === "business" ? t("yourNameBiz") : t("yourNamePerson")}<input value={name} onChange={(e) => setName(e.target.value)} autoComplete={type === "business" ? "organization" : "given-name"} maxLength={60} /></label>
        </>)}
        <label>{t("email")}<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" inputMode="email" autoCapitalize="none" /></label>
        <label>{t("password")}
          <span className="pwrow">
            <input type={showPw ? "text" : "password"} value={pw} onChange={(e) => setPw(e.target.value)} autoComplete={mode === "in" ? "current-password" : "new-password"} />
            <button type="button" className="pwtoggle" onClick={() => setShowPw(!showPw)}>{showPw ? t("hidePw") : t("showPw")}</button>
          </span>
          {mode === "up" && <small className="help">{t("passwordHelp")}</small>}</label>
        {mode === "up" && (
          <label className="check"><input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
            <span>I agree to the <a href="#/terms">Terms of Use</a> and <a href="#/privacy">Privacy Policy</a></span></label>
        )}
        {api.mode === "demo" && <p className="note">{t("demoNoEmail")}</p>}
        {info && <p className="banner ok">{info}</p>}
        {err && <p className="err" role="alert">{err}</p>}
        <button className="btn full" disabled={busy}>{mode === "in" ? t("login") : t("register")}</button>
        {mode === "in" && <button type="button" className="link center block" onClick={forgot}>{t("forgot")}</button>}
      </form>
    </div>
  );
}

export function Recovery() {
  const { api, t, toast, go } = useApp();
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  return (
    <div className="screen login">
      <div className="login-head"><Logo size={56} /><h1>{t("setNewPw")}</h1></div>
      <form onSubmit={async (e) => { e.preventDefault(); if (pw.length < 6) return setErr(t("shortPw"));
        try { await api.updatePassword(pw); toast(t("pwUpdated")); go("/", true); } catch { setErr(t("error")); } }}>
        <label>{t("newPassword")}<input type="password" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="new-password" autoFocus /></label>
        {err && <p className="err" role="alert">{err}</p>}
        <button className="btn full">{t("save")}</button>
      </form>
    </div>
  );
}

export function Me() {
  const { api, t, go, uid, me, refreshMe, toast, lang, theme, setTheme, needAuth, isAdmin } = useApp();
  const [form, setForm] = useState<ProfileInput | null>(null);
  const [resetOpen, setResetOpen] = useState(false);
  const [delOpen, setDelOpen] = useState(false);
  const [delText, setDelText] = useState("");
  const [photoBusy, setPhotoBusy] = useState(false);
  useEffect(() => { needAuth(); }, [needAuth]);
  useEffect(() => { if (me) setForm({ name: me.name, postcode: me.postcode, bio: me.bio, avatar_url: me.avatar_url, account_type: me.account_type || "person",
    headline: me.headline || "", skills: me.skills || [], available: !!me.available, available_days: me.available_days || [], lat: me.lat, lng: me.lng }); }, [me]);
  const [lists, reloadLists] = useLoad(async () => (uid ? { apps: await api.myApplications(), mine: await api.myListings(), alerts: await api.savedSearches() } : null), [api, uid]);
  if (!uid || !me || !form) return <div className="screen"><Loading /></div>;
  const toggle = (arr: string[], v: string) => (arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);

  const save = async () => {
    if (isOffensive(form.name + " " + form.bio + " " + form.headline)) return toast(t("offensive"));
    const postcode = form.postcode.trim().toUpperCase().slice(0, 10);
    const g = locate(postcode);
    await api.saveProfile({ ...form, name: form.name.trim().slice(0, 60), postcode, bio: form.bio.trim(), headline: form.headline.trim().slice(0, 80), lat: g?.lat ?? null, lng: g?.lng ?? null });
    await refreshMe();
    toast(t("profileSaved"));
  };
  return (
    <div className="screen">
      <h1 className="pagetitle">{t("profile")}</h1>
      {me.banned && <p className="banner off">{t("banned")}</p>}
      <div className="mehead">
        <label className="avatarpick" aria-label={t("changePhoto")}>
          <Avatar p={me} size={72} />
          <span className="cam"><Icon name="camera" size={15} /></span>
          <input type="file" accept="image/*" hidden disabled={photoBusy} onChange={async (e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            setPhotoBusy(true);
            try { const url = await api.uploadPhoto(f); await api.saveProfile({ ...form, avatar_url: url }); await refreshMe(); toast(t("photoSaved")); }
            catch { toast(t("error")); } finally { setPhotoBusy(false); }
          }} />
        </label>
        <button className="owner flat grow" onClick={() => go("/u/" + uid)}>
        <span className="grow"><b>{me.name || t("you")}</b><br /><Stars small value={me.rating_avg} count={me.rating_count} /></span>
        <Icon name="back" size={18} />
      </button>
      </div>
      {isAdmin && <button className="admintile" onClick={() => go("/admin")}><Icon name="shield" /> <b>{t("adminPanel")}</b><Icon name="back" size={16} /></button>}
      <div className="tiles">
        <button onClick={() => go("/dashboard")}><Icon name="chart" /> {t("dashboard")}</button>
        <button onClick={() => go("/notices")}><Icon name="bell" /> {t("notices")}</button>
        <button onClick={() => go("/saved")}><Icon name="heart" /> {t("savedListings")}</button>
        <button onClick={() => go("/inbox")}><Icon name="chat" /> {t("inbox")}</button>
      </div>

      <h2 className="sec">{t("myListings")}</h2>
      {!lists ? <Loading /> : lists.mine.length ? lists.mine.map((l) => <ListingCard key={l.id} l={l} />) :
        <Empty icon="plus" text={t("none")} action={<button className="btn" onClick={() => go("/post")}>{t("newListing")}</button>} />}

      <h2 className="sec">{t("myApplications")}</h2>
      {!lists ? <Loading /> : lists.apps.length ? lists.apps.map((a) => (
        <button key={a.id} className="thread" onClick={() => go("/chat/" + a.id)}>
          <span className="grow"><b className="ellip block">{a.listing?.title}</b><span className="mute xs">{a.listing?.owner?.name} · {a.listing ? fmtDate(lang, a.listing.date) : ""}</span></span>
          <span className={"status sm st-" + a.status}>{t(("st." + a.status) as Key)}</span>
        </button>
      )) : <p className="mute">{t("none")}</p>}

      <h2 className="sec">{t("alerts")}</h2>
      {!lists ? <Loading /> : lists.alerts.length ? lists.alerts.map((a) => (
        <div key={a.id} className="alertrow"><Icon name="bell" size={16} /><span className="grow ellip">{a.label}</span>
          <button className="iconbtn" aria-label={t("delete")} onClick={async () => { await api.deleteSearch(a.id); reloadLists(); }}><Icon name="x" size={16} /></button></div>
      )) : <p className="mute">{t("none")}</p>}
      <PushToggle />

      <h2 className="sec">{t("profile")}</h2>
      <span className="lbl">{t("accountType")}</span>
      <div className="seg">
        {(["person", "business"] as const).map((x) => <button key={x} className={form.account_type === x ? "on" : ""} onClick={() => setForm({ ...form, account_type: x, available: x === "business" ? false : form.available })}>{t(x)}</button>)}
      </div>
      <label>{t("yourName")}<input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} maxLength={60} autoComplete="name" /></label>
      <label>{t("postcode")}<input value={form.postcode} onChange={(e) => setForm({ ...form, postcode: e.target.value })} maxLength={10} placeholder="BS31" />
        <small className="help">{t("postcodeHelp")}</small></label>
      {form.account_type === "person" && (<>
        <label className="switch"><input type="checkbox" checked={form.available} onChange={(e) => setForm({ ...form, available: e.target.checked })} />
          <span className="grow"><b>{t("lookingForWork")}</b><small className="help">{t("lookingHelp")}</small></span><i /></label>
        {form.available && (<>
          <label>{t("headline")}<input value={form.headline} onChange={(e) => setForm({ ...form, headline: e.target.value })} placeholder={t("headlinePh")} maxLength={80} /></label>
          <span className="lbl">{t("skills")}</span>
          <div className="chips wrap">{CATEGORIES.filter((c) => c !== "other").map((c) => (
            <button key={c} className={"chip" + (form.skills.includes(c) ? " on" : "")} aria-pressed={form.skills.includes(c)} onClick={() => setForm({ ...form, skills: toggle(form.skills, c) })}>{t(("cat." + c) as Key)}</button>
          ))}</div>
          <span className="lbl">{t("availableDays")}</span>
          <div className="days big">{DAYS.map((d) => (
            <button key={d} className={form.available_days.includes(d) ? "on" : ""} aria-pressed={form.available_days.includes(d)} onClick={() => setForm({ ...form, available_days: toggle(form.available_days, d) })}>{t(("day." + d) as Key)}</button>
          ))}</div>
        </>)}
      </>)}
      <label>{t("bio")}<textarea rows={3} value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} placeholder={t("bioPh")} maxLength={500} /></label>
      <button className="btn full" onClick={save}>{t("saveProfile")}</button>

      <h2 className="sec">{t("theme")}</h2>
      <div className="seg">
        {(["auto", "light", "dark"] as Theme[]).map((x) => <button key={x} className={theme === x ? "on" : ""} onClick={() => setTheme(x)}>{t(x === "auto" ? "themeAuto" : x === "light" ? "themeLight" : "themeDark")}</button>)}
      </div>

      <h2 className="sec">{t("legalSection")}</h2>
      <div className="linklist">
        <button onClick={() => go("/blocked")}><Icon name="x" size={16} /> {t("blockedUsers")}<Icon name="back" size={14} /></button>
        <button onClick={() => go("/terms")}><Icon name="list" size={16} /> {t("terms")}<Icon name="back" size={14} /></button>
        <button onClick={() => go("/privacy")}><Icon name="lock" size={16} /> {t("privacy")}<Icon name="back" size={14} /></button>
        <div className="linkrow"><Icon name="chat" size={16} /> {t("contactUs")}: <b>{COMPANY.email}</b></div>
      </div>

      <button className="btn ghost full" onClick={() => api.signOut()}>{t("signOut")}</button>
      <button className="link danger center block" onClick={() => { setDelText(""); setDelOpen(true); }}>{t("deleteAccount")}</button>
      {api.mode === "demo" && <button className="link muted-link center block" onClick={() => setResetOpen(true)}>{t("resetDemo")}</button>}
      <p className="mute xs center">NearTask · {COMPANY.name}</p>
      <Sheet open={delOpen} onClose={() => setDelOpen(false)} title={t("deleteAccount")}>
        <p>{t("deleteHelp")}</p>
        <label>{t("typeDelete")}<input value={delText} onChange={(e) => setDelText(e.target.value)} autoCapitalize="characters" /></label>
        <div className="btnrow pad"><button className="btn ghost" onClick={() => setDelOpen(false)}>{t("cancel")}</button>
          <button className="btn danger" disabled={delText.trim().toUpperCase() !== "DELETE"} onClick={async () => {
            try { await api.deleteAccount(); setDelOpen(false); toast(t("accountDeleted")); go("/", true); } catch { toast(t("error")); }
          }}><Icon name="trash" /> {t("delete")}</button></div>
      </Sheet>
      <Sheet open={resetOpen} onClose={() => setResetOpen(false)} title={t("resetDemo")}>
        <p>{t("resetConfirm")}</p>
        <div className="btnrow"><button className="btn ghost" onClick={() => setResetOpen(false)}>{t("cancel")}</button>
          <button className="btn danger" onClick={() => { api.resetDemo?.(); location.hash = "/"; location.reload(); }}>{t("delete")}</button></div>
      </Sheet>
    </div>
  );
}

export function UserView({ id }: { id: string }) {
  const { api, t, lang, uid, go, toast, needAuth, blocked, refreshBlocked } = useApp();
  const [inviteOpen, setInviteOpen] = useState(false);
  const [menu, setMenu] = useState<"" | "block" | "report">("");
  const [reason, setReason] = useState("");
  const [myOpen, setMyOpen] = useState<Listing[] | null>(null);
  const [pick, setPick] = useState("");
  const [msg, setMsg] = useState("");
  const [data] = useLoad(async () => {
    const [p, reviews, listings] = await Promise.all([api.getProfile(id), api.reviewsFor(id), api.listListings({ kind: "all", when: "any", category: "all", q: "", sort: "soon" })]);
    return { p, reviews, listings: listings.filter((l) => l.owner_id === id) };
  }, [api, id]);
  if (!data) return <div className="screen"><TopBar backTo="/" /><Loading /></div>;
  const { p, reviews, listings } = data;
  if (!p) return <div className="screen"><TopBar backTo="/" /><Empty icon="user" text={t("notFound")} /></div>;
  const isBlocked = blocked.has(p.id);
  const other = uid && uid !== p.id;
  return (
    <div className="screen">
      <TopBar backTo="/" right={other ? <>
        <button className="iconbtn" aria-label={t("reportUser")} onClick={() => { setReason(""); setMenu("report"); }}><Icon name="flag" /></button>
        <button className="iconbtn" aria-label={t("block")} onClick={async () => {
          if (isBlocked) { await api.unblock(p.id); await refreshBlocked(); toast(t("unblockedDone")); } else setMenu("block");
        }}><Icon name="x" /></button>
      </> : undefined} />
      {isBlocked && <p className="banner off">{t("youBlocked")} <button className="link" onClick={async () => { await api.unblock(p.id); await refreshBlocked(); toast(t("unblockedDone")); }}>{t("unblock")}</button></p>}
      <Sheet open={menu === "block"} onClose={() => setMenu("")} title={t("blockQ", { name: p.name })}>
        <p>{t("blockHelp")}</p>
        <div className="btnrow pad"><button className="btn ghost" onClick={() => setMenu("")}>{t("cancel")}</button>
          <button className="btn danger" onClick={async () => { await api.block(p.id); await refreshBlocked(); setMenu(""); toast(t("blockedDone")); }}>{t("block")}</button></div>
      </Sheet>
      <Sheet open={menu === "report"} onClose={() => setMenu("")} title={t("reportUser")}>
        <p className="mute">{t("reportUserQ")}</p>
        <textarea rows={4} value={reason} onChange={(e) => setReason(e.target.value)} maxLength={500} />
        <button className="btn full danger" disabled={!reason.trim()} onClick={async () => { await api.reportUser(p.id, reason.trim()).catch(() => {}); setMenu(""); toast(t("reported")); }}>{t("send")}</button>
      </Sheet>
      <div className="phead">
        <Avatar p={p} size={84} />
        <h1>{p.name || "—"}</h1>
        <div className="prow">
          {p.verified && <span className="vtag"><Icon name="check" size={12} /> {t("verified")}</span>}
          <Stars value={p.rating_avg} count={p.rating_count} />
          {p.postcode && <span className="tag ghost"><Icon name="pin" size={12} /> {p.postcode}</span>}
        </div>
        <span className="mute xs">{t("memberSince", { d: fmtDate(lang, p.created_at.slice(0, 10), { month: "long", year: "numeric" }) })}</span>
        {p.headline && <p className="headline">{p.headline}</p>}
        {p.bio && <p className="prose center">{p.bio}</p>}
        {p.skills?.length > 0 && <div className="chips wrap center">{p.skills.map((s) => <span key={s} className={"tag cat-" + s}>{t(("cat." + s) as Key)}</span>)}</div>}
        {p.available && <div className="days">{DAYS.map((d) => <i key={d} className={p.available_days.includes(d) ? "on" : ""}>{t(("day." + d) as Key)}</i>)}</div>}
        {p.available && uid !== p.id && !isBlocked && <button className="btn" onClick={async () => {
          if (needAuth()) return;
          const mine = (await api.myListings()).filter((l) => l.status === "open" && l.kind === "job" && l.date >= new Date().toISOString().slice(0, 10));
          setMyOpen(mine); setPick(mine[0]?.id || ""); setMsg(t("inviteMsg", { name: p.name.split(" ")[0] })); setInviteOpen(true);
        }}><Icon name="briefcase" /> {t("invite")}</button>}
      </div>
      <Sheet open={inviteOpen} onClose={() => setInviteOpen(false)} title={t("invite")}>
        {!myOpen?.length ? (<><p>{t("noOpenListings")}</p><button className="btn full" onClick={() => go("/post")}>{t("newListing")}</button></>) : (<>
          <span className="lbl">{t("chooseListing")}</span>
          <div className="picklist">{myOpen.map((l) => (
            <button key={l.id} className={pick === l.id ? "on" : ""} onClick={() => setPick(l.id)}><b className="ellip block">{l.title}</b><span className="mute xs">{fmtDate(lang, l.date)} · {l.pay}</span></button>
          ))}</div>
          <textarea rows={3} value={msg} onChange={(e) => setMsg(e.target.value)} maxLength={1000} />
          <button className="btn full" disabled={!pick || !msg.trim()} onClick={async () => {
            try { const appId = await api.invite(pick, p.id, msg.trim()); setInviteOpen(false); toast(t("inviteSent")); go("/chat/" + appId); } catch { toast(t("error")); }
          }}><Icon name="send" /> {t("send")}</button>
        </>)}
      </Sheet>
      {listings.length > 0 && <><h2 className="sec">{t("latest")}</h2>{listings.map((l) => <ListingCard key={l.id} l={l} />)}</>}
      <h2 className="sec">{t("reviews")}</h2>
      {reviews.length ? reviews.map((r) => (
        <div className="review" key={r.id}>
          <Avatar p={r.reviewer} size={34} />
          <div className="grow"><span className="trow"><b>{r.reviewer?.name}</b><span className="mute xs">{fmtAgo(lang, r.created_at)}</span></span>
            <span className="rstars">{"★".repeat(r.stars)}<span className="mute">{"★".repeat(5 - r.stars)}</span></span>
            {r.comment && <p>{r.comment}</p>}</div>
        </div>
      )) : <p className="mute">{t("noReviews")}</p>}
    </div>
  );
}

export function BlockedList() {
  const { api, t, refreshBlocked, toast, go } = useApp();
  const [list, reload] = useLoad(() => api.blockedProfiles(), [api]);
  return (
    <div className="screen">
      <TopBar title={t("blockedUsers")} backTo="/me" />
      {!list ? <Loading /> : !list.length ? <Empty icon="user" text={t("noBlocked")} /> : list.map((p) => (
        <div key={p.id} className="thread">
          <Avatar p={p} size={40} />
          <button className="grow link-plain" onClick={() => go("/u/" + p.id)}><b>{p.name}</b></button>
          <button className="btn ghost sm" onClick={async () => { await api.unblock(p.id); await refreshBlocked(); reload(); toast(t("unblockedDone")); }}>{t("unblock")}</button>
        </div>
      ))}
    </div>
  );
}
