import { useEffect, useRef, useState } from "react";
import { useApp } from "../state";
import type { Application, Message, Review } from "../types";
import { Avatar, Empty, Icon, Loading, Sheet, TopBar, useLoad } from "../ui";
import { fmtAgo, fmtDate, type Key } from "../i18n";
import { isOffensive } from "../moderation";

export function Inbox() {
  const { t, go, lang, threads, isUnread, uid, needAuth, blocked } = useApp();
  useEffect(() => { needAuth(); }, [needAuth]);
  if (!uid) return <div className="screen"><Loading /></div>;
  return (
    <div className="screen">
      <h1 className="pagetitle">{t("inbox")}</h1>
      {!threads.length ? <Empty icon="chat" text={t("noThreads")} action={<button className="btn" onClick={() => go("/explore")}>{t("explore")}</button>} /> :
        threads.filter((th) => !blocked.has(th.other?.id)).map((th) => {
          const un = isUnread(th);
          return (
            <button key={th.app.id} className={"thread" + (un ? " unread" : "")} onClick={() => go("/chat/" + th.app.id)}>
              <Avatar p={th.other} size={48} />
              <span className="grow">
                <span className="trow"><b className="ellip">{th.other?.name}</b><span className="mute xs">{th.last ? fmtAgo(lang, th.last.created_at) : ""}</span></span>
                <span className="mute xs ellip block">{th.listing.title} · {fmtDate(lang, th.listing.date)}</span>
                <span className="ellip block tlast">{th.last ? (th.last.sender_id === uid ? t("you") + ": " : "") + th.last.body : ""}</span>
              </span>
              <span className={"status sm st-" + th.app.status}>{t(("st." + th.app.status) as Key)}</span>
              {un && <span className="dot" aria-label={t("newMsg")} />}
            </button>
          );
        })}
    </div>
  );
}

export function Chat({ id }: { id: string }) {
  const { api, t, lang, uid, go, markSeen, toast, refreshThreads, needAuth, blocked } = useApp();
  const [app, setApp] = useState<Application | null>();
  const [msgs, setMsgs] = useState<Message[]>([]);
  const [text, setText] = useState("");
  const [rateOpen, setRateOpen] = useState(false);
  const [stars, setStars] = useState(5);
  const [comment, setComment] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  const [myReview, reloadReview] = useLoad<Review | null>(() => (uid ? api.myReview(id) : Promise.resolve(null)), [api, id, uid]);

  useEffect(() => { needAuth(); }, [needAuth]);
  useEffect(() => {
    let live = true;
    const load = async () => {
      const [a, m] = await Promise.all([api.getApplication(id), api.messages(id)]);
      if (!live) return;
      setApp(a); setMsgs(m); markSeen(id);
    };
    load();
    const off = api.subscribe(id, load);
    return () => { live = false; off(); };
  }, [api, id, markSeen]);
  useEffect(() => { endRef.current?.scrollIntoView({ block: "end" }); }, [msgs.length]);

  if (app === undefined) return <div className="screen"><TopBar backTo="/inbox" /><Loading /></div>;
  if (!app || !app.listing) return <div className="screen"><TopBar backTo="/inbox" /><Empty icon="chat" text={t("notFound")} /></div>;
  const l = app.listing;
  const owner = l.owner_id === uid;
  const other = owner ? app.applicant : l.owner;

  const send = async () => {
    const body = text.trim();
    if (!body) return;
    if (isOffensive(body)) return toast(t("offensive"));
    setText("");
    try { await api.send(id, body); refreshThreads(); } catch { toast(t("error")); setText(body); }
  };
  const setStatus = async (s: "accepted" | "declined" | "withdrawn") => { await api.setApplicationStatus(id, s); toast(t(("st." + s) as Key)); };
  const submitReview = async () => {
    try { await api.review(id, other!.id, stars, comment.trim()); toast(t("thanksReview")); setRateOpen(false); reloadReview(); } catch { toast(t("error")); }
  };

  let lastDay = "";
  return (
    <div className="screen chat">
      <TopBar backTo="/inbox" title={other?.name} right={<button className="iconbtn" onClick={() => go("/u/" + other?.id)} aria-label={t("profile")}><Avatar p={other} size={32} /></button>} />
      <button className="ctx" onClick={() => go("/l/" + l.id)}>
        <span className="grow ellip"><span className="mute xs">{t("aboutListing")}</span><br /><b>{l.title}</b> · {fmtDate(lang, l.date)} · {l.pay}</span>
        <span className={"status sm st-" + app.status}>{t(("st." + app.status) as Key)}</span>
      </button>
      {app.status === "accepted" && !owner && <p className="banner ok"><Icon name="check" size={16} /> {t("acceptedBanner")}</p>}
      {!owner && app.status === "invited" && (<>
        <p className="banner invite"><Icon name="briefcase" size={16} /> {t("invitedBanner", { name: other?.name || "" })}</p>
        <div className="btnrow pad"><button className="btn ghost" onClick={() => setStatus("declined")}>{t("decline")}</button>
          <button className="btn" onClick={() => setStatus("accepted")}><Icon name="check" /> {t("acceptInvite")}</button></div>
      </>)}
      {owner && app.status === "pending" && (
        <div className="btnrow pad"><button className="btn ghost" onClick={() => setStatus("declined")}>{t("decline")}</button>
          <button className="btn" onClick={() => setStatus("accepted")}><Icon name="check" /> {t("accept")}</button></div>
      )}
      {app.status === "accepted" && (myReview ? <p className="mute xs center">{t("youRated", { n: myReview.stars })}</p> :
        <button className="ratebtn" onClick={() => setRateOpen(true)}><Icon name="star" fill size={16} /> {t("rate", { name: other?.name || "" })}</button>)}

      <div className="msgs" aria-live="polite">
        {msgs.map((m) => {
          const day = m.created_at.slice(0, 10);
          const sep = day !== lastDay ? (lastDay = day, <div className="daysep" key={"d" + m.id}>{fmtDate(lang, day)}</div>) : null;
          const mine = m.sender_id === uid;
          return [sep, <div key={m.id} className={"bubble" + (mine ? " me" : "")}>{m.body}<span className="time">{new Date(m.created_at).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}</span></div>];
        })}
        <div ref={endRef} />
      </div>
      {!owner && app.status === "pending" && <button className="link center block muted-link" onClick={() => setStatus("withdrawn")}>{t("withdraw")}</button>}
      {other && blocked.has(other.id) ? <p className="banner off">{t("youBlocked")}</p> : <form className="composer" onSubmit={(e) => { e.preventDefault(); send(); }}>
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder={t("messagePh")} aria-label={t("messagePh")} enterKeyHint="send" maxLength={2000} />
        <button className="sendbtn" type="submit" disabled={!text.trim()} aria-label={t("send")}><Icon name="send" /></button>
      </form>}

      <Sheet open={rateOpen} onClose={() => setRateOpen(false)} title={t("rate", { name: other?.name || "" })}>
        <p className="mute">{t("rateHint")}</p>
        <div className="starpick" role="radiogroup">
          {[1, 2, 3, 4, 5].map((n) => (
            <button key={n} role="radio" aria-checked={stars === n} aria-label={n + "★"} className={n <= stars ? "on" : ""} onClick={() => setStars(n)}><Icon name="star" size={34} fill={n <= stars} /></button>
          ))}
        </div>
        <textarea rows={3} value={comment} onChange={(e) => setComment(e.target.value)} placeholder={t("ratePh")} maxLength={500} />
        <button className="btn full" onClick={submitReview}>{t("send")}</button>
      </Sheet>
    </div>
  );
}
