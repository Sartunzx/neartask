import { useEffect, useState } from "react";
import { useApp } from "../state";
import { CatBadge, Empty, Icon, Loading, TopBar, useLoad } from "../ui";
import { fmtAgo, fmtDate } from "../i18n";
import { enablePush, pushState, type PushState } from "../push";
import { whenOf } from "../util";

const NOTICE_ICON: Record<string, string> = {
  message: "chat", application: "user", accepted: "check", declined: "x", invite: "briefcase", review: "star", alert: "bell", welcome: "home",
};

export function PushToggle() {
  const { api, t } = useApp();
  const [st, setSt] = useState<PushState>(pushState);
  if (st === "on") return <p className="pushrow on"><Icon name="check" size={16} /> {t("pushOn")}</p>;
  if (st === "denied") return <p className="pushrow">{t("pushDenied")}</p>;
  if (st === "unsupported") return <p className="pushrow">{t("pushUnsupported")}</p>;
  return <button className="btn ghost full pushbtn" onClick={async () => setSt(await enablePush(api))}><Icon name="bell" /> {t("enablePush")}</button>;
}

export function Notices() {
  const { t, lang, notices, markNoticesRead, go, uid, needAuth } = useApp();
  const [snapshot] = useState(() => new Set(notices.filter((n) => !n.read).map((n) => n.id)));
  useEffect(() => { needAuth(); }, [needAuth]);
  useEffect(() => { if (uid) { const id = setTimeout(markNoticesRead, 600); return () => clearTimeout(id); } }, [uid, markNoticesRead]);
  return (
    <div className="screen">
      <TopBar title={t("notices")} backTo="/" />
      <PushToggle />
      {!notices.length ? <Empty icon="bell" text={t("noNotices")} /> : notices.map((n) => (
        <button key={n.id} className={"notice" + (snapshot.has(n.id) || !n.read ? " unread" : "")} onClick={() => go(n.link)}>
          <span className={"nic n-" + n.type}><Icon name={NOTICE_ICON[n.type] || "bell"} size={18} /></span>
          <span className="grow">
            <b className="block">{n.title}</b>
            {n.body && <span className="mute ellip block">{n.body}</span>}
            <span className="mute xs">{fmtAgo(lang, n.created_at)}</span>
          </span>
        </button>
      ))}
    </div>
  );
}

export function Dashboard() {
  const { api, t, lang, go, uid, needAuth } = useApp();
  useEffect(() => { needAuth(); }, [needAuth]);
  const [rows] = useLoad(() => (uid ? api.dashboard() : Promise.resolve([])), [api, uid]);
  if (!rows) return <div className="screen"><TopBar title={t("dashboard")} backTo="/me" /><Loading /></div>;
  const live = rows.filter((r) => r.listing.status === "open" && whenOf(r.listing.date) !== "past");
  const sum = (f: (r: (typeof rows)[number]) => number) => rows.reduce((s, r) => s + f(r), 0);
  const tiles: [string, number, string][] = [
    [t("dActive"), live.length, "briefcase"],
    [t("dPending"), sum((r) => r.pending), "user"],
    [t("dFilled"), sum((r) => r.accepted), "check"],
    [t("dViews"), sum((r) => r.listing.views || 0), "chart"],
  ];
  const maxViews = Math.max(1, ...rows.map((r) => r.listing.views || 0));
  return (
    <div className="screen">
      <TopBar title={t("dashboard")} backTo="/me" right={<button className="iconbtn" onClick={() => go("/post")} aria-label={t("post")}><Icon name="plus" /></button>} />
      <div className="kpis">
        {tiles.map(([label, v, icon]) => (
          <div key={label} className="kpi"><Icon name={icon} size={18} /><b>{v.toLocaleString()}</b><span>{label}</span></div>
        ))}
      </div>
      {!rows.length ? <Empty icon="briefcase" text={t("none")} action={<button className="btn" onClick={() => go("/post")}>{t("newListing")}</button>} /> : rows.map((r) => {
        const l = r.listing;
        const past = whenOf(l.date) === "past";
        return (
          <div key={l.id} className={"drow" + (past ? " dim" : "")}>
            <button className="drow-main" onClick={() => go("/l/" + l.id)}>
              <CatBadge c={l.category} size={40} />
              <span className="grow">
                <b className="ellip block">{l.title}</b>
                <span className="mute xs">{fmtDate(lang, l.date)} · {l.pay}{l.status !== "open" ? " · " + t(l.status === "filled" ? "filled" : "closed") : ""}</span>
                <span className="bar"><i style={{ width: (100 * (l.views || 0)) / maxViews + "%" }} /></span>
                <span className="dstats">
                  <span>{t("viewsN", { n: l.views || 0 })}</span>
                  <span>{t("applicantsN", { n: r.applicants })}</span>
                  <span className={r.accepted >= (l.positions || 1) ? "ok" : ""}>{t("filledOf", { a: r.accepted, b: l.positions || 1 })}</span>
                </span>
              </span>
            </button>
            <div className="drow-actions">
              {r.pending > 0 && <button className="btn sm" onClick={() => go("/manage/" + l.id)}>{t("dPending")} · {r.pending}</button>}
              <button className="btn ghost sm" onClick={() => go("/copy/" + l.id)}><Icon name="copy" size={16} /> {t("duplicate")}</button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
