// Demo mode: a complete fake backend that lives in the browser.
// Sample people answer your messages, accept invites and post new listings, so every flow can be tried without a server.
import type { AdminReport, Api, Application, AppStatus, Listing, ListingInput, Message, Notice, Profile, Review, SavedSearch, Thread, Filters, ListingStatus } from "../types";
import { applyFilters, blobToDataUrl, lsGet, lsSet, shrinkImage, today, uid } from "../util";
import { km, locate } from "../geo";

const KEY = "neartask_demo_v3";
const ME = "me";

type SeedListing = Listing & { offset?: number };
interface DB {
  v: 3;
  session: string | null;
  users: Profile[];
  listings: SeedListing[];
  priv: Record<string, string>;
  apps: Application[];
  msgs: Message[];
  favs: Record<string, string[]>;
  reviews: Review[];
  reports: { listing_id: string; reason: string }[];
  bot: Record<string, number>;
  notices: Notice[];
  searches: SavedSearch[];
  blocks: string[];
  reports2: AdminReport[];
  mineSeeded?: boolean;
}

const ago = (mins: number) => new Date(Date.now() - mins * 60000).toISOString();
function person(id: string, name: string, postcode: string, o: Partial<Profile> = {}): Profile {
  const p = locate(postcode);
  return {
    id, name, postcode, bio: "", avatar_url: null, rating_avg: 0, rating_count: 0, verified: false, created_at: ago(60 * 24 * 120),
    account_type: "person", headline: "", skills: [], available: false, available_days: [], lat: p?.lat ?? null, lng: p?.lng ?? null, ...o,
  };
}
const WEEKDAYS = ["mon", "tue", "wed", "thu", "fri"], WEEKEND = ["sat", "sun"];

function seed(): DB {
  const biz = { account_type: "business" as const, verified: true };
  const users = [
    person(ME, "", ""),
    person("hotel", "Keynsham Hotel (sample)", "BS31", { ...biz, bio: "Busy country-house hotel and restaurant.", rating_avg: 4.8, rating_count: 23 }),
    person("cafe", "Riverside Café (sample)", "BS31", { ...biz, bio: "Family café by the river.", rating_avg: 4.6, rating_count: 11 }),
    person("trade", "Unit 4 Trade Supplies (sample)", "BS31", { account_type: "business", bio: "Building and trade supplies.", rating_avg: 4.3, rating_count: 7 }),
    person("pub", "The Lock Keeper (sample)", "BS31", { ...biz, bio: "Riverside pub and kitchen.", rating_avg: 4.5, rating_count: 9 }),
    person("anna", "Anna (sample)", "BS31", { bio: "Saltford homeowner.", rating_avg: 4.9, rating_count: 5 }),
    person("david", "David (sample)", "BA2", { bio: "Moving house in Bath.", rating_avg: 4.5, rating_count: 2 }),
    person("helen", "Helen (sample)", "BS31", { bio: "Retired teacher, needs a hand now and then.", rating_avg: 5, rating_count: 9 }),
    person("tom", "Tom (sample)", "BS31", { headline: "Experienced waiter and bar staff", bio: "5 years in hotels and restaurants. Food hygiene level 2.", skills: ["hospitality"], available: true, available_days: ["fri", "sat", "sun"], rating_avg: 4.7, rating_count: 14, verified: true }),
    person("priya", "Priya (sample)", "BS4", { headline: "Student, evenings and weekends", bio: "Friendly, reliable and quick to learn.", skills: ["hospitality", "cleaning"], available: true, available_days: [...WEEKEND, "wed"], rating_avg: 4.4, rating_count: 3 }),
    person("jake", "Jake (sample)", "BS30", { headline: "Warehouse and moving, own van", bio: "Forklift licence. Happy to lift.", skills: ["warehouse", "moving"], available: true, available_days: WEEKDAYS, rating_avg: 4.8, rating_count: 21, verified: true }),
    person("maria", "Maria (sample)", "BS31", { headline: "Professional cleaner", bio: "Homes and holiday lets. Brings own supplies.", skills: ["cleaning", "care"], available: true, available_days: ["mon", "tue", "thu", "sat"], rating_avg: 4.9, rating_count: 32, verified: true }),
    person("olu", "Olu (sample)", "BA1", { headline: "Handyman and gardener", bio: "Small repairs, flat-pack, hedges and lawns.", skills: ["repairs", "garden"], available: true, available_days: [...WEEKDAYS, "sat"], rating_avg: 4.6, rating_count: 12 }),
    person("sophie", "Sophie (sample)", "BS14", { headline: "Chef de partie", bio: "Kitchen experience in busy hotels.", skills: ["hospitality"], available: true, available_days: ["thu", "fri", "sat"], rating_avg: 4.7, rating_count: 6 }),
    person("ben", "Ben (sample)", "BA2", { headline: "Carer and errands", bio: "DBS checked. Shopping, lifts, companionship.", skills: ["care"], available: true, available_days: WEEKDAYS, rating_avg: 5, rating_count: 8 }),
  ];
  const L = (id: string, owner_id: string, kind: "job" | "service", title: string, category: any, area: string, offset: number,
    start: string | null, end: string | null, pay: string, description: string, requirements: string, created: number, positions = 1, views = 0): SeedListing => {
    const p = locate(area);
    return { id, owner_id, kind, title, category, area, offset, date: today(offset), start_time: start, end_time: end, pay, description,
      requirements, photo_url: null, status: "open", created_at: ago(created), positions, views, lat: p?.lat ?? null, lng: p?.lng ?? null };
  };
  const listings = [
    L("s1", "hotel", "job", "Waiter, evening shift", "hospitality", "Keynsham BS31", 1, "18:00", "22:00", "£13.50/hr",
      "Serve dinner in a busy hotel restaurant. Friendly team, staff meal included.", "Right to work in the UK. Smart black clothes.", 40, 2, 37),
    L("s2", "cafe", "job", "Kitchen porter", "hospitality", "Keynsham BS31", 0, "12:00", "16:00", "£12.80/hr",
      "Wash up and help keep the kitchen clean over the lunch rush.", "Right to work in the UK.", 90, 1, 22),
    L("s3", "trade", "job", "Warehouse packer", "warehouse", "Keynsham BS31", 3, "08:00", "14:00", "£12.50/hr",
      "Pick and pack trade orders. Light lifting, steel toe-caps provided.", "Right to work in the UK.", 300, 3, 51),
    L("s4", "anna", "service", "Garden tidy-up", "garden", "Saltford BS31", 5, "09:00", "12:00", "£60",
      "Cut the hedge and clear leaves from a small front garden. Tools provided.", "Own transport helpful.", 200, 1, 14),
    L("s5", "helen", "service", "House clean, 3 hours", "cleaning", "Keynsham BS31", 1, "10:00", "13:00", "£45",
      "Two-bed flat, kitchen and bathroom focus.", "Please bring your own supplies.", 25, 1, 9),
    L("s6", "david", "service", "Help moving a sofa", "moving", "Bath BA2", 0, "14:00", "15:00", "£30",
      "Move a sofa from a ground-floor flat to a van. Two people needed.", "Able to lift.", 15, 2, 18),
    L("s7", "hotel", "job", "Housekeeping assistant", "hospitality", "Keynsham BS31", 2, "09:00", "14:00", "£12.60/hr",
      "Prepare guest rooms to a high standard. Training given.", "Right to work in the UK.", 120, 2, 29),
    L("s8", "helen", "service", "Fix a dripping tap", "repairs", "Keynsham BS31", 4, null, null, "£40",
      "Kitchen mixer tap drips constantly. Probably needs a new cartridge.", "Basic plumbing tools.", 500, 1, 6),
    L("s9", "pub", "job", "Bar staff, Saturday", "hospitality", "Keynsham BS31", 6, "17:00", "23:00", "£12.70/hr + tips",
      "Pull pints and serve food on our busiest night.", "Right to work in the UK. 18+.", 60, 2, 12),
    L("s10", "cafe", "job", "Barista, weekend mornings", "hospitality", "Bristol BS4", 5, "07:30", "12:30", "£12.60/hr",
      "Make coffee and serve breakfast at our Bristol branch.", "Barista experience preferred.", 400, 1, 20),
    L("s11", "ben", "service", "Weekly shopping trip", "care", "Bath BA1", 3, "10:00", "12:00", "£25",
      "Drive an elderly neighbour to the supermarket and help carry bags.", "Car and clean licence.", 80, 1, 4),
  ];
  const addr = "(sample address)";
  const priv: Record<string, string> = Object.fromEntries(listings.map((l) => [l.id, l.area + " " + addr]));
  const reviews: Review[] = [
    { id: "r1", application_id: "x", reviewer_id: "tom", reviewee_id: "hotel", stars: 5, comment: "Well organised and paid on time.", created_at: ago(9000) },
    { id: "r2", application_id: "x", reviewer_id: "priya", reviewee_id: "cafe", stars: 4, comment: "Nice team, busy lunch.", created_at: ago(20000) },
    { id: "r3", application_id: "x", reviewer_id: "hotel", reviewee_id: "tom", stars: 5, comment: "Excellent with guests.", created_at: ago(15000) },
    { id: "r4", application_id: "x", reviewer_id: "helen", reviewee_id: "maria", stars: 5, comment: "Spotless. Will book again.", created_at: ago(5000) },
    { id: "r5", application_id: "x", reviewer_id: "trade", reviewee_id: "jake", stars: 5, comment: "Hard worker, on time every day.", created_at: ago(7000) },
  ];
  return { v: 3, session: null, users, listings, priv, apps: [], msgs: [], favs: {}, reviews, reports: [], bot: {}, notices: [], searches: [], blocks: [], reports2: [] };
}

export function createDemoApi(): Api {
  let db: DB = lsGet<DB | null>(KEY, null) || seed();
  if (db.v !== 3) db = seed();
  db.blocks = db.blocks || [];
  db.reports2 = db.reports2 || [];
  db.listings.forEach((l) => { if (l.offset !== undefined) l.date = today(l.offset); });
  const save = () => lsSet(KEY, db);
  save();

  const subs = new Map<string, Set<() => void>>();
  const allSubs = new Set<() => void>();
  const authSubs = new Set<(u: string | null) => void>();
  const noticeSubs = new Set<(n: Notice) => void>();
  const emit = (appId: string) => { subs.get(appId)?.forEach((f) => f()); allSubs.forEach((f) => f()); };

  const user = (id: string) => db.users.find((u) => u.id === id)!;
  const withOwner = (l: Listing): Listing => ({ ...l, owner: user(l.owner_id) });
  const listing = (id: string) => db.listings.find((l) => l.id === id);
  const need = () => { if (!db.session) throw new Error("auth"); return db.session; };
  const fullApp = (a: Application): Application => ({ ...a, listing: withOwner(listing(a.listing_id)!), applicant: user(a.applicant_id) });
  const later = (ms: number, fn: () => void) => setTimeout(fn, ms);
  const short = (n: string) => n.replace(/\s*\(sample\)/, "");

  function notify(userId: string, type: string, title: string, body: string, link: string) {
    if (userId !== ME) return;
    const n: Notice = { id: uid(), type, title, body: body.slice(0, 140), link, read: false, created_at: new Date().toISOString() };
    db.notices.unshift(n);
    save();
    noticeSubs.forEach((f) => f(n));
  }
  function post(appId: string, sender: string, body: string) {
    db.msgs.push({ id: uid(), application_id: appId, sender_id: sender, body, created_at: new Date().toISOString() });
    const a = db.apps.find((x) => x.id === appId);
    if (a) {
      const l = listing(a.listing_id)!;
      const to = sender === a.applicant_id ? l.owner_id : a.applicant_id;
      notify(to, "message", short(user(sender).name) + " · " + l.title, body, "/chat/" + appId);
    }
    save();
    emit(appId);
  }
  function setStatus(a: Application, status: AppStatus) {
    const old = a.status;
    a.status = status;
    const l = listing(a.listing_id)!;
    if (status === "accepted" && l.status === "open" && db.apps.filter((x) => x.listing_id === l.id && x.status === "accepted").length >= (l.positions || 1)) l.status = "filled";
    if (old === "pending" && (status === "accepted" || status === "declined"))
      notify(a.applicant_id, status, (status === "accepted" ? "Accepted: " : "Declined: ") + l.title, "", "/chat/" + a.id);
    if (old === "invited" && (status === "accepted" || status === "declined"))
      notify(l.owner_id, status, short(user(a.applicant_id).name) + " " + status + " your invite", l.title, "/chat/" + a.id);
    save();
    emit(a.id);
  }

  const OWNER_SCRIPT = [
    "Thanks for getting in touch! Are you free for the full time?",
    "Great. Any similar experience?",
    "Perfect, you're confirmed. The exact address is now on the listing. See you then!",
  ];
  const APPLICANT_SCRIPT = ["Thanks! Happy to answer any questions.", "Yes, that works for me.", "Great, see you then."];

  function botReply(appId: string) {
    const a = db.apps.find((x) => x.id === appId);
    if (!a) return;
    const l = listing(a.listing_id)!;
    const n = db.bot[appId] || 0;
    if (n >= 3) return;
    db.bot[appId] = n + 1;
    if (a.applicant_id === ME) {
      later(1600, () => {
        post(appId, l.owner_id, OWNER_SCRIPT[n]);
        if (n === 2 && a.status === "pending") setStatus(a, "accepted");
      });
    } else later(1600, () => post(appId, a.applicant_id, APPLICANT_SCRIPT[n]));
  }

  function seedMine() {
    if (db.mineSeeded) return;
    db.mineSeeded = true;
    const id = "mine1";
    const p = locate("BS31");
    db.listings.unshift({
      id, owner_id: ME, kind: "job", title: "Breakfast service, Sunday", category: "hospitality", area: "Keynsham BS31",
      date: today(2), offset: 2, start_time: "07:00", end_time: "11:00", pay: "£13/hr", positions: 2, views: 46, lat: p!.lat, lng: p!.lng,
      description: "Help serve breakfast to hotel guests. This is a sample listing so you can try managing applicants.",
      requirements: "Right to work in the UK.", photo_url: null, status: "open", created_at: ago(180),
    } as SeedListing);
    db.priv[id] = "Your address (sample)";
    const mk = (who: string, message: string, mins: number) => {
      const a: Application = { id: uid(), listing_id: id, applicant_id: who, message, status: "pending", created_at: ago(mins) };
      db.apps.push(a);
      db.msgs.push({ id: uid(), application_id: a.id, sender_id: who, body: message, created_at: a.created_at });
      db.notices.unshift({ id: uid(), type: "application", title: "New applicant: " + short(user(who).name), body: "Breakfast service, Sunday", link: "/manage/" + id, read: false, created_at: a.created_at });
    };
    mk("tom", "Hi, I've done breakfast service for 5 years. I'd love this shift.", 120);
    mk("priya", "Hello! I'm free Sunday morning and learn fast.", 45);
    db.notices.unshift({ id: uid(), type: "welcome", title: "Welcome to NearTask", body: "Turn on alerts in Explore to hear about new listings first.", link: "/explore", read: false, created_at: ago(1) });
  }

  const api: Api = {
    mode: "demo",
    async currentUser() { return db.session; },
    onAuthChange(cb) { authSubs.add(cb); return () => authSubs.delete(cb); },
    async signUp(email, password) { if (password.length < 6) throw new Error("short"); await api.verifyCode(email, "000000"); return "ok"; },
    async signIn(email, password) { if (!/^\S+@\S+\.\S+$/.test(email) || !password) throw new Error("wrong"); await api.verifyCode(email, "000000"); },
    async resetPassword() {},
    async updatePassword() {},
    onRecovery() { return () => {}; },
    async sendCode(email) { if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error("email"); },
    async verifyCode(email, code) {
      if (!/^\d{6}$/.test(code)) throw new Error("code");
      db.session = ME;
      const me = user(ME);
      me.is_admin = true; // demo: you are the admin so the panel can be tried
      if (!me.name) me.name = email.split("@")[0].replace(/[._-]+/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()).slice(0, 30);
      seedMine();
      save();
      authSubs.forEach((f) => f(ME));
    },
    async signOut() { db.session = null; save(); authSubs.forEach((f) => f(null)); },

    async getProfile(id) { return db.users.find((u) => u.id === id) || null; },
    async saveProfile(p) { const me = user(need()); Object.assign(me, p); save(); },
    async listWorkers(skill, near) {
      const list = db.users.filter((u) => u.available && u.account_type === "person" && u.id !== db.session && (skill === "all" || u.skills.includes(skill)));
      const d = (u: Profile) => (near && u.lat != null ? km(near, { lat: u.lat, lng: u.lng! }) : 999);
      return list.sort((a, b) => d(a) - d(b) || b.rating_avg - a.rating_avg);
    },
    async stats() {
      return {
        seekers: db.users.filter((u) => u.available && u.account_type === "person").length,
        businesses: db.users.filter((u) => u.account_type === "business").length,
        listings: applyFilters(db.listings, { kind: "all", when: "any", category: "all", q: "", sort: "soon" }).length,
      };
    },

    async listListings(f: Filters) { return applyFilters(db.listings.map(withOwner), f); },
    async getListing(id) { const l = listing(id); return l ? withOwner(l) : null; },
    async myListings() { const me = need(); return db.listings.filter((l) => l.owner_id === me).map(withOwner); },
    async saveListing(inp: ListingInput) {
      const me = need();
      const { address, ...rest } = inp;
      const p = locate(inp.area);
      const geo = { lat: p?.lat ?? null, lng: p?.lng ?? null };
      if (inp.id) {
        const l = listing(inp.id);
        if (!l || l.owner_id !== me) throw new Error("forbidden");
        Object.assign(l, rest, geo);
        delete l.offset;
      } else {
        const id = uid();
        db.listings.unshift({ ...rest, ...geo, id, owner_id: me, status: "open", views: 0, created_at: new Date().toISOString() } as Listing);
        inp.id = id;
      }
      db.priv[inp.id!] = address;
      save();
      return inp.id!;
    },
    async setListingStatus(id, status: ListingStatus) { const l = listing(id); if (l && l.owner_id === need()) { l.status = status; save(); } },
    async deleteListing(id) {
      const me = need();
      db.listings = db.listings.filter((l) => !(l.id === id && l.owner_id === me));
      const gone = db.apps.filter((a) => a.listing_id === id).map((a) => a.id);
      db.apps = db.apps.filter((a) => a.listing_id !== id);
      db.msgs = db.msgs.filter((m) => !gone.includes(m.application_id));
      save();
      allSubs.forEach((f) => f());
    },
    async getAddress(listingId) {
      const me = db.session;
      const l = listing(listingId);
      if (!me || !l) return null;
      if (l.owner_id === me || db.apps.some((a) => a.listing_id === listingId && a.applicant_id === me && a.status === "accepted")) return db.priv[listingId] || "";
      return null;
    },
    async uploadPhoto(file) { return blobToDataUrl(await shrinkImage(file, 720)); },
    async viewListing(id) { const l = listing(id); if (l && l.owner_id !== db.session) { l.views = (l.views || 0) + 1; save(); } },
    async dashboard() {
      const me = need();
      return db.listings.filter((l) => l.owner_id === me).map((l) => {
        const apps = db.apps.filter((a) => a.listing_id === l.id);
        return { listing: withOwner(l), applicants: apps.filter((a) => a.status !== "invited").length,
          pending: apps.filter((a) => a.status === "pending").length, accepted: apps.filter((a) => a.status === "accepted").length };
      });
    },
    async invite(listingId, workerId, message) {
      const me = need();
      const l = listing(listingId);
      if (!l || l.owner_id !== me) throw new Error("forbidden");
      let a = db.apps.find((x) => x.listing_id === listingId && x.applicant_id === workerId);
      if (!a) {
        a = { id: uid(), listing_id: listingId, applicant_id: workerId, message, status: "invited", created_at: new Date().toISOString() };
        db.apps.push(a);
        post(a.id, me, message);
        const app = a;
        later(2200, () => { post(app.id, workerId, "Thanks for the invite! Yes, I can do it."); setStatus(app, "accepted"); });
      }
      return a.id;
    },

    async apply(listingId, message) {
      const me = need();
      const l = listing(listingId)!;
      if (l.owner_id === me) throw new Error("own");
      let a = db.apps.find((x) => x.listing_id === listingId && x.applicant_id === me);
      if (!a) {
        a = { id: uid(), listing_id: listingId, applicant_id: me, message, status: "pending", created_at: new Date().toISOString() };
        db.apps.push(a);
      } else if (a.status === "withdrawn") a.status = "pending";
      post(a.id, me, message);
      botReply(a.id);
      return a.id;
    },
    async myApplications() { const me = need(); return db.apps.filter((a) => a.applicant_id === me).map(fullApp).reverse(); },
    async applicationsFor(listingId) { return db.apps.filter((a) => a.listing_id === listingId).map(fullApp); },
    async getApplication(id) { const a = db.apps.find((x) => x.id === id); return a ? fullApp(a) : null; },
    async setApplicationStatus(id, status) {
      const a = db.apps.find((x) => x.id === id);
      if (!a) return;
      setStatus(a, status);
      if (status === "accepted" && a.applicant_id !== ME) later(1400, () => post(id, a.applicant_id, "Brilliant, thank you! I'll be there on time."));
    },

    async threads() {
      const me = db.session;
      if (!me) return [];
      const out: Thread[] = [];
      for (const a of db.apps) {
        const l = listing(a.listing_id);
        if (!l || (a.applicant_id !== me && l.owner_id !== me)) continue;
        const ms = db.msgs.filter((m) => m.application_id === a.id);
        out.push({ app: fullApp(a), listing: withOwner(l), other: user(l.owner_id === me ? a.applicant_id : l.owner_id), last: ms[ms.length - 1] || null, mineIsOwner: l.owner_id === me });
      }
      return out.sort((x, y) => (y.last?.created_at || y.app.created_at).localeCompare(x.last?.created_at || x.app.created_at));
    },
    async messages(appId) { return db.msgs.filter((m) => m.application_id === appId); },
    async send(appId, body) { const me = need(); post(appId, me, body); botReply(appId); },
    subscribe(appId, cb) {
      if (!subs.has(appId)) subs.set(appId, new Set());
      subs.get(appId)!.add(cb);
      return () => subs.get(appId)!.delete(cb);
    },
    subscribeAll(cb) { allSubs.add(cb); return () => allSubs.delete(cb); },

    async favorites() { return db.session ? db.favs[db.session] || [] : []; },
    async toggleFavorite(listingId) {
      const me = need();
      const f = (db.favs[me] = db.favs[me] || []);
      const i = f.indexOf(listingId);
      if (i > -1) f.splice(i, 1); else f.push(listingId);
      save();
      return i === -1;
    },

    async review(appId, revieweeId, stars, comment) {
      const me = need();
      if (db.reviews.some((r) => r.application_id === appId && r.reviewer_id === me)) return;
      db.reviews.push({ id: uid(), application_id: appId, reviewer_id: me, reviewee_id: revieweeId, stars, comment, created_at: new Date().toISOString() });
      const mine = db.reviews.filter((r) => r.reviewee_id === revieweeId);
      const u = user(revieweeId);
      u.rating_count = mine.length;
      u.rating_avg = Math.round((mine.reduce((s, r) => s + r.stars, 0) / mine.length) * 100) / 100;
      save();
    },
    async reviewsFor(userId) {
      return db.reviews.filter((r) => r.reviewee_id === userId).map((r) => ({ ...r, reviewer: user(r.reviewer_id) })).reverse();
    },
    async myReview(appId) { return db.reviews.find((r) => r.application_id === appId && r.reviewer_id === db.session) || null; },

    async report(listingId, reason) {
      const l = listing(listingId);
      db.reports2.unshift({ id: uid(), reason, status: "open", created_at: new Date().toISOString(), listing_id: listingId, reported_user_id: null,
        listing_title: l?.title || null, listing_status: l?.status || null, listing_owner: l?.owner_id || null,
        reporter_name: user(ME).name, reported_name: l ? user(l.owner_id).name : null, reported_banned: false });
      save();
    },
    async deleteAccount() { db = seed(); save(); authSubs.forEach((f) => f(null)); },
    async blockedIds() { return db.blocks; },
    async blockedProfiles() { return db.blocks.map(user).filter(Boolean); },
    async block(u) { if (!db.blocks.includes(u)) db.blocks.push(u); save(); },
    async unblock(u) { db.blocks = db.blocks.filter((x) => x !== u); save(); },
    async reportUser(u, reason) {
      db.reports2.unshift({ id: uid(), reason, status: "open", created_at: new Date().toISOString(), listing_id: null, reported_user_id: u,
        listing_title: null, listing_status: null, listing_owner: null, reporter_name: user(ME).name, reported_name: user(u)?.name || null, reported_banned: !!user(u)?.banned });
      save();
    },
    async adminOverview() {
      return { users: db.users.length, businesses: db.users.filter((u) => u.account_type === "business").length,
        seekers: db.users.filter((u) => u.available).length, open_listings: applyFilters(db.listings, { kind: "all", when: "any", category: "all", q: "", sort: "soon" }).length,
        applications: db.apps.length, messages_7d: db.msgs.length, new_users_7d: 1, open_reports: db.reports2.filter((r) => r.status === "open").length };
    },
    async adminReports() {
      if (!db.reports2.length) db.reports2.push({ id: uid(), reason: "Asks applicants to pay a 'registration fee'.", status: "open", created_at: ago(90), listing_id: "s8", reported_user_id: null,
        listing_title: "Fix a dripping tap", listing_status: "open", listing_owner: "helen", reporter_name: "Priya (sample)", reported_name: "Helen (sample)", reported_banned: false });
      return db.reports2.map((r) => ({ ...r, listing_status: r.listing_id ? listing(r.listing_id)?.status || null : null, reported_banned: !!user(r.reported_user_id || r.listing_owner || "")?.banned }));
    },
    async adminResolveReport(id, status) { const r = db.reports2.find((x) => x.id === id); if (r) r.status = status; save(); },
    async adminSetListingStatus(id, status) { const l = listing(id); if (l) l.status = status; save(); },
    async adminSetVerified(u, v) { const p = user(u); if (p) p.verified = v; save(); },
    async adminSetBanned(u, v) { const p = user(u); if (p) { p.banned = v; if (v) db.listings.forEach((l) => { if (l.owner_id === u && l.status === "open") l.status = "closed"; }); } save(); },
    async adminSearch(q) { const s = q.toLowerCase(); return db.users.filter((u) => u.id !== ME && (!s || u.name.toLowerCase().includes(s))); },

    async notifications() { return db.session ? db.notices.slice(0, 50) : []; },
    async markAllRead() { db.notices.forEach((n) => (n.read = true)); save(); },
    onNotification(cb) { noticeSubs.add(cb); return () => noticeSubs.delete(cb); },
    async savedSearches() { return db.session ? db.searches : []; },
    async saveSearch(s) {
      need();
      db.searches.unshift({ ...s, id: uid(), created_at: new Date().toISOString() });
      save();
      // Demo: a matching listing appears a few seconds later, to show how alerts work.
      later(5000, () => {
        const kind = s.kind === "service" ? "service" : "job";
        const cat = s.category !== "all" ? s.category : kind === "job" ? "hospitality" : "cleaning";
        const owner = kind === "job" ? "pub" : "anna";
        const p = locate("BS31");
        const l = { id: uid(), owner_id: owner, kind, title: (s.q ? s.q[0].toUpperCase() + s.q.slice(1) + " – " : "") + (kind === "job" ? "Extra shift this weekend" : "Help needed this weekend"),
          category: cat, area: "Keynsham BS31", date: today(4), offset: 4, start_time: "10:00", end_time: "15:00", pay: kind === "job" ? "£13/hr" : "£50",
          description: "New sample listing created to show how alerts work.", requirements: "", photo_url: null, status: "open", created_at: new Date().toISOString(),
          positions: 1, views: 0, lat: p!.lat, lng: p!.lng } as SeedListing;
        db.listings.unshift(l);
        db.priv[l.id] = "Keynsham BS31 (sample address)";
        notify(ME, "alert", "New match: " + l.title, l.area + " · " + l.pay, "/l/" + l.id);
      });
    },
    async deleteSearch(id) { db.searches = db.searches.filter((s) => s.id !== id); save(); },
    resetDemo() { const s = db.session; db = seed(); save(); if (s) authSubs.forEach((f) => f(null)); },
  };
  return api;
}
