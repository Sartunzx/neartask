// Live mode: real accounts, shared data and live chat through Supabase.
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import type { AdminOverview, AdminReport, Api, Application, Filters, Listing, ListingInput, ListingStats, Message, Notice, Profile, Review, SavedSearch, Stats, Thread } from "../types";
import { geocode, km } from "../geo";
import { applyFilters, shrinkImage, today } from "../util";

const LISTING = "*, owner:profiles!listings_owner_id_fkey(*)";
const APP = "*, listing:listings(" + LISTING + "), applicant:profiles!applications_applicant_id_fkey(*)";

/** Turn Supabase auth errors into short codes the screens can explain. */
function authErr(e: { message?: string; status?: number; code?: string }): string {
  const m = (e.message || "") + " " + (e.code || "");
  if (e.status === 429 || /rate limit|too many/i.test(m)) return "rate";
  if (/already registered|already exists|user_already_exists/i.test(m)) return "exists";
  if (/not confirmed|email_not_confirmed/i.test(m)) return "unconfirmed";
  if (/invalid login|invalid_credentials|invalid grant/i.test(m)) return "wrong";
  if (/weak|password should|at least/i.test(m)) return "weak";
  if (/fetch|network/i.test(m)) return "network";
  return "other:" + (e.message || "");
}

export function createSupabaseApi(url: string, key: string): Api {
  const recovering = /type=recovery/.test(location.hash);
  const sb: SupabaseClient = createClient(url, key, { auth: { persistSession: true, autoRefreshToken: true } });
  let me: string | null = null;
  const ready = sb.auth.getSession().then(({ data }) => { me = data.session?.user.id ?? null; });
  sb.auth.onAuthStateChange((_e, s) => { me = s?.user.id ?? null; });

  const need = async () => { await ready; if (!me) throw new Error("auth"); return me; };
  const ok = <T>(r: { data: T; error: any }): T => { if (r.error) throw new Error(r.error.message); return r.data; };

  const api: Api = {
    mode: "live",
    async currentUser() { await ready; return me; },
    onAuthChange(cb) {
      const { data } = sb.auth.onAuthStateChange((_e, s) => cb(s?.user.id ?? null));
      return () => data.subscription.unsubscribe();
    },
    async signUp(email, password) {
      const r = await sb.auth.signUp({ email, password, options: { emailRedirectTo: location.origin + location.pathname } });
      if (r.error) throw new Error(authErr(r.error));
      return r.data.session ? "ok" : "confirm";
    },
    async signIn(email, password) {
      const r = await sb.auth.signInWithPassword({ email, password });
      if (r.error) throw new Error(authErr(r.error));
    },
    async resetPassword(email) {
      const r = await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + location.pathname });
      if (r.error) throw new Error(authErr(r.error));
    },
    async updatePassword(password) { ok(await sb.auth.updateUser({ password })); },
    onRecovery(cb) {
      if (recovering) setTimeout(cb, 0);
      const { data } = sb.auth.onAuthStateChange((e) => { if (e === "PASSWORD_RECOVERY") cb(); });
      return () => data.subscription.unsubscribe();
    },
    async sendCode(email) {
      ok(await sb.auth.signInWithOtp({ email, options: { shouldCreateUser: true } }));
    },
    async verifyCode(email, code) {
      ok(await sb.auth.verifyOtp({ email, token: code, type: "email" }));
    },
    async signOut() { await sb.auth.signOut(); },

    async getProfile(id) { return ok(await sb.from("profiles").select("*").eq("id", id).maybeSingle()) as Profile | null; },
    async saveProfile(p) {
      const id = await need();
      const g = p.postcode ? await geocode(p.postcode, true) : null;
      ok(await sb.from("profiles").update({ ...p, lat: g?.lat ?? null, lng: g?.lng ?? null }).eq("id", id));
    },
    async listWorkers(skill, near) {
      let q = sb.from("profiles").select("*").eq("available", true).eq("account_type", "person").limit(100);
      if (skill !== "all") q = q.contains("skills", [skill]);
      const rows = (ok(await q) as Profile[]).filter((p) => p.id !== me);
      const d = (u: Profile) => (near && u.lat != null ? km(near, { lat: u.lat, lng: u.lng! }) : 999);
      return rows.sort((a, b) => d(a) - d(b) || b.rating_avg - a.rating_avg);
    },
    async stats() { return ok(await sb.rpc("public_stats")) as Stats; },

    async listListings(f: Filters) {
      let q = sb.from("listings").select(LISTING).eq("status", "open").gte("date", today()).limit(200);
      if (f.kind !== "all") q = q.eq("kind", f.kind);
      if (f.category !== "all") q = q.eq("category", f.category);
      if (f.when === "today") q = q.eq("date", today());
      if (f.when === "tomorrow") q = q.eq("date", today(1));
      if (f.when === "week") q = q.lte("date", today(7));
      const term = f.q.replace(/[%,()*]/g, " ").trim();
      if (term) q = q.or(`title.ilike.%${term}%,area.ilike.%${term}%,description.ilike.%${term}%`);
      const rows = ok(await q) as Listing[];
      return applyFilters(rows, { ...f, q: "" });
    },
    async getListing(id) { return ok(await sb.from("listings").select(LISTING).eq("id", id).maybeSingle()) as Listing | null; },
    async myListings() {
      const id = await need();
      return ok(await sb.from("listings").select(LISTING).eq("owner_id", id).order("date", { ascending: false })) as Listing[];
    },
    async saveListing(inp: ListingInput) {
      await need();
      const { address, id, ...data } = inp;
      const g = await geocode(inp.area, true);
      const rest = { ...data, lat: g?.lat ?? null, lng: g?.lng ?? null };
      let lid = id;
      if (lid) ok(await sb.from("listings").update(rest).eq("id", lid));
      else lid = (ok(await sb.from("listings").insert(rest).select("id").single()) as { id: string }).id;
      ok(await sb.from("listing_private").upsert({ listing_id: lid, address }));
      return lid!;
    },
    async setListingStatus(id, status) { ok(await sb.from("listings").update({ status }).eq("id", id)); },
    async deleteListing(id) { ok(await sb.from("listings").delete().eq("id", id)); },
    async getAddress(listingId) {
      await ready;
      if (!me) return null;
      const r = ok(await sb.from("listing_private").select("address").eq("listing_id", listingId).maybeSingle()) as { address: string } | null;
      return r ? r.address : null;
    },
    async uploadPhoto(file) {
      const id = await need();
      const blob = await shrinkImage(file);
      const path = `${id}/${Date.now()}.jpg`;
      ok(await sb.storage.from("photos").upload(path, blob, { contentType: "image/jpeg" }));
      return sb.storage.from("photos").getPublicUrl(path).data.publicUrl;
    },

    async viewListing(id) { await sb.rpc("view_listing", { l: id }); },
    async dashboard() {
      const id = await need();
      const ls = ok(await sb.from("listings").select(LISTING).eq("owner_id", id).order("date", { ascending: false })) as Listing[];
      if (!ls.length) return [];
      const apps = ok(await sb.from("applications").select("listing_id,status").in("listing_id", ls.map((l) => l.id))) as { listing_id: string; status: string }[];
      return ls.map((l): ListingStats => {
        const a = apps.filter((x) => x.listing_id === l.id);
        return { listing: l, applicants: a.filter((x) => x.status !== "invited").length, pending: a.filter((x) => x.status === "pending").length, accepted: a.filter((x) => x.status === "accepted").length };
      });
    },
    async invite(listingId, workerId, message) {
      await need();
      const existing = ok(await sb.from("applications").select("id").eq("listing_id", listingId).eq("applicant_id", workerId).maybeSingle()) as { id: string } | null;
      if (existing) return existing.id;
      const appId = (ok(await sb.from("applications").insert({ listing_id: listingId, applicant_id: workerId, status: "invited", message }).select("id").single()) as { id: string }).id;
      ok(await sb.from("messages").insert({ application_id: appId, body: message }));
      return appId;
    },

    async apply(listingId, message) {
      const id = await need();
      const existing = ok(await sb.from("applications").select("id,status").eq("listing_id", listingId).eq("applicant_id", id).maybeSingle()) as { id: string; status: string } | null;
      let appId = existing?.id;
      if (!appId) appId = (ok(await sb.from("applications").insert({ listing_id: listingId, message }).select("id").single()) as { id: string }).id;
      else if (existing!.status === "withdrawn") ok(await sb.from("applications").update({ status: "pending" }).eq("id", appId));
      ok(await sb.from("messages").insert({ application_id: appId, body: message }));
      return appId;
    },
    async myApplications() {
      const id = await need();
      return ok(await sb.from("applications").select(APP).eq("applicant_id", id).order("created_at", { ascending: false })) as Application[];
    },
    async applicationsFor(listingId) {
      return ok(await sb.from("applications").select(APP).eq("listing_id", listingId).order("created_at")) as Application[];
    },
    async getApplication(id) { return ok(await sb.from("applications").select(APP).eq("id", id).maybeSingle()) as Application | null; },
    async setApplicationStatus(id, status) { ok(await sb.from("applications").update({ status }).eq("id", id)); },

    async threads() {
      await ready;
      if (!me) return [];
      // RLS returns only applications where I am the applicant or the listing owner.
      const apps = ok(await sb.from("applications").select(APP).order("created_at", { ascending: false }).limit(100)) as Application[];
      if (!apps.length) return [];
      const msgs = ok(await sb.from("messages").select("*").in("application_id", apps.map((a) => a.id)).order("created_at", { ascending: false }).limit(500)) as Message[];
      const last = new Map<string, Message>();
      msgs.forEach((m) => { if (!last.has(m.application_id)) last.set(m.application_id, m); });
      const out: Thread[] = apps.filter((a) => a.listing).map((a) => {
        const owner = a.listing!.owner_id === me;
        return { app: a, listing: a.listing!, other: (owner ? a.applicant : a.listing!.owner)!, last: last.get(a.id) || null, mineIsOwner: owner };
      });
      return out.sort((x, y) => (y.last?.created_at || y.app.created_at).localeCompare(x.last?.created_at || x.app.created_at));
    },
    async messages(appId) {
      return ok(await sb.from("messages").select("*").eq("application_id", appId).order("created_at")) as Message[];
    },
    async send(appId, body) { await need(); ok(await sb.from("messages").insert({ application_id: appId, body })); },
    subscribe(appId, cb) {
      const ch = sb.channel("app:" + appId)
        .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `application_id=eq.${appId}` }, () => cb())
        .on("postgres_changes", { event: "UPDATE", schema: "public", table: "applications", filter: `id=eq.${appId}` }, () => cb())
        .subscribe();
      return () => { sb.removeChannel(ch); };
    },
    subscribeAll(cb) {
      const ch = sb.channel("inbox")
        .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages" }, () => cb())
        .on("postgres_changes", { event: "*", schema: "public", table: "applications" }, () => cb())
        .subscribe();
      return () => { sb.removeChannel(ch); };
    },

    async favorites() {
      await ready;
      if (!me) return [];
      return (ok(await sb.from("favorites").select("listing_id")) as { listing_id: string }[]).map((r) => r.listing_id);
    },
    async toggleFavorite(listingId) {
      const id = await need();
      const has = ok(await sb.from("favorites").select("listing_id").eq("listing_id", listingId).maybeSingle());
      if (has) { ok(await sb.from("favorites").delete().eq("listing_id", listingId).eq("user_id", id)); return false; }
      ok(await sb.from("favorites").insert({ listing_id: listingId }));
      return true;
    },

    async review(appId, revieweeId, stars, comment) {
      await need();
      ok(await sb.from("reviews").insert({ application_id: appId, reviewee_id: revieweeId, stars, comment }));
    },
    async reviewsFor(userId) {
      return ok(await sb.from("reviews").select("*, reviewer:profiles!reviews_reviewer_id_fkey(*)").eq("reviewee_id", userId).order("created_at", { ascending: false }).limit(50)) as Review[];
    },
    async myReview(appId) {
      const id = await need();
      return ok(await sb.from("reviews").select("*").eq("application_id", appId).eq("reviewer_id", id).maybeSingle()) as Review | null;
    },

    async report(listingId, reason) { await need(); ok(await sb.from("reports").insert({ listing_id: listingId, reason })); },

    async notifications() {
      await ready;
      if (!me) return [];
      return ok(await sb.from("notifications").select("*").order("created_at", { ascending: false }).limit(50)) as Notice[];
    },
    async markAllRead() { const id = await need(); ok(await sb.from("notifications").update({ read: true }).eq("user_id", id).eq("read", false)); },
    onNotification(cb) {
      const ch = sb.channel("notices")
        .on("postgres_changes", { event: "INSERT", schema: "public", table: "notifications" }, (p: any) => cb(p.new as Notice))
        .subscribe();
      return () => { sb.removeChannel(ch); };
    },
    async savedSearches() {
      await ready;
      if (!me) return [];
      return ok(await sb.from("saved_searches").select("*").order("created_at", { ascending: false })) as SavedSearch[];
    },
    async saveSearch(s) { await need(); ok(await sb.from("saved_searches").insert(s)); },
    async deleteSearch(id) { ok(await sb.from("saved_searches").delete().eq("id", id)); },
    async deleteAccount() { await need(); ok(await sb.rpc("delete_my_account")); await sb.auth.signOut(); },
    async blockedIds() {
      await ready;
      if (!me) return [];
      return (ok(await sb.from("blocks").select("blocked_id")) as { blocked_id: string }[]).map((r) => r.blocked_id);
    },
    async blockedProfiles() {
      const ids = await api.blockedIds();
      if (!ids.length) return [];
      return ok(await sb.from("profiles").select("*").in("id", ids)) as Profile[];
    },
    async block(userId) { await need(); ok(await sb.from("blocks").upsert({ blocked_id: userId })); },
    async unblock(userId) { const id = await need(); ok(await sb.from("blocks").delete().eq("blocker_id", id).eq("blocked_id", userId)); },
    async reportUser(userId, reason) { await need(); ok(await sb.from("reports").insert({ reported_user_id: userId, reason })); },

    async adminOverview() { return ok(await sb.rpc("admin_overview")) as AdminOverview; },
    async adminReports() { return (ok(await sb.rpc("admin_reports")) as AdminReport[]) || []; },
    async adminResolveReport(id, status) { ok(await sb.rpc("admin_resolve_report", { r: id, s: status })); },
    async adminSetListingStatus(id, status) { ok(await sb.rpc("admin_set_listing_status", { l: id, s: status })); },
    async adminSetVerified(userId, v) { ok(await sb.rpc("admin_set_verified", { u: userId, v })); },
    async adminSetBanned(userId, v) { ok(await sb.rpc("admin_set_banned", { u: userId, v })); },
    async adminSearch(q) {
      const term = q.replace(/[%,()*]/g, " ").trim();
      let query = sb.from("profiles").select("*").order("created_at", { ascending: false }).limit(50);
      if (term) query = query.ilike("name", `%${term}%`);
      return ok(await query) as Profile[];
    },
    async savePush(sub) { await need(); ok(await sb.from("push_subscriptions").upsert({ endpoint: sub.endpoint, subscription: sub })); },
  };
  return api;
}
