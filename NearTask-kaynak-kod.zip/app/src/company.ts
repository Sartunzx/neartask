// Legal details shown in the app, the privacy policy and the terms.
// Fill in the blanks with the details registered at Companies House before publishing to the app stores.
export const COMPANY = {
  name: "Artwin Ltd",
  number: "", // Companies House number, e.g. "12345678"
  address: "", // Registered office address
  email: "support@artwin.co.uk",
  ico: "", // ICO registration number, once registered
  updated: "25 October 2026",
};
