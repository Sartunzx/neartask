import type { Api, Notice } from "./types";

export type PushState = "unsupported" | "denied" | "on" | "off";

export function pushState(): PushState {
  if (!("Notification" in window)) return "unsupported";
  if (Notification.permission === "denied") return "denied";
  return Notification.permission === "granted" ? "on" : "off";
}

function b64ToBytes(b64: string) {
  const pad = "=".repeat((4 - (b64.length % 4)) % 4);
  const raw = atob((b64 + pad).replace(/-/g, "+").replace(/_/g, "/"));
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
}

/** Ask for permission; in live mode also register this phone for push messages while the app is closed. */
export async function enablePush(api: Api): Promise<PushState> {
  if (!("Notification" in window)) return "unsupported";
  let perm: NotificationPermission = Notification.permission;
  try { if (perm === "default") perm = await Notification.requestPermission(); } catch { return "unsupported"; }
  if (perm !== "granted") return perm === "denied" ? "denied" : "off";
  const key = (import.meta as any).env?.VITE_VAPID_PUBLIC_KEY as string | undefined;
  if (api.mode === "live" && key && api.savePush && "serviceWorker" in navigator) {
    try {
      const reg = await navigator.serviceWorker.ready;
      const sub = (await reg.pushManager.getSubscription()) || (await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToBytes(key) }));
      await api.savePush(sub.toJSON());
    } catch {}
  }
  return "on";
}

/** While the app is open in the background, show a system notification. */
export function showLocal(n: Notice) {
  if (!("Notification" in window) || Notification.permission !== "granted" || !document.hidden) return;
  try {
    const note = new Notification(n.title, { body: n.body, icon: "icon.svg", tag: n.id });
    note.onclick = () => { window.focus(); location.hash = n.link; note.close(); };
  } catch {}
}
