import { createRoot } from "react-dom/client";
import { App } from "./App";
import { AppProvider } from "./state";
import { loadApi } from "./api";
import "./styles.css";

loadApi().then((api) => {
  createRoot(document.getElementById("root")!).render(
    <AppProvider api={api}>
      <App />
    </AppProvider>
  );
});

// Offline support and "Add to home screen" (only on a real https site, not inside previews).
if ("serviceWorker" in navigator && location.protocol === "https:" && window.top === window.self) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
}
