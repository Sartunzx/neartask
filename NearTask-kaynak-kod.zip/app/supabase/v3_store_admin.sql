-- ==== PART 1: admin + ban flags, blocks ====
alter table public.profiles add column if not exists is_admin boolean not null default false;
alter table public.profiles add column if not exists banned boolean not null default false;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin from profiles where id = auth.uid()), false)
$$;

create or replace function public.is_banned() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select banned from profiles where id = auth.uid()), false)
$$;

create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id)
);
alter table public.blocks enable row level security;
drop policy if exists "blocks own" on public.blocks;
create policy "blocks own" on public.blocks for all using (blocker_id = auth.uid()) with check (blocker_id = auth.uid());

create or replace function public.blocked_between(a uuid, b uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from blocks where (blocker_id = a and blocked_id = b) or (blocker_id = b and blocked_id = a))
$$;

-- ==== PART 2: stricter insert rules (banned users and blocked pairs) ====
drop policy if exists "listings insert" on public.listings;
create policy "listings insert" on public.listings for insert with check (owner_id = auth.uid() and not public.is_banned());

drop policy if exists "applications insert" on public.applications;
create policy "applications insert" on public.applications for insert with check (
  not public.is_banned()
  and exists (select 1 from public.listings l where l.id = listing_id and l.status = 'open'
    and not public.blocked_between(l.owner_id, applicant_id)) and (
    (applicant_id = auth.uid() and status = 'pending' and not public.is_listing_owner(listing_id))
    or (status = 'invited' and public.is_listing_owner(listing_id) and applicant_id <> auth.uid())
  ));

create or replace function public.can_message(a uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from applications ap join listings li on li.id = ap.listing_id
    where ap.id = a and (ap.applicant_id = auth.uid() or li.owner_id = auth.uid())
      and not blocked_between(ap.applicant_id, li.owner_id)
  ) and not is_banned()
$$;

drop policy if exists "messages insert" on public.messages;
create policy "messages insert" on public.messages for insert with check (sender_id = auth.uid() and public.can_message(application_id));

-- ==== PART 3: report users, delete own account ====
alter table public.reports alter column listing_id drop not null;
alter table public.reports add column if not exists reported_user_id uuid references public.profiles(id) on delete cascade;
alter table public.reports add column if not exists status text not null default 'open';
do $$ begin
  alter table public.reports add constraint reports_target check (listing_id is not null or reported_user_id is not null);
exception when duplicate_object then null; end $$;

create or replace function public.delete_my_account() returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  delete from storage.objects where bucket_id = 'photos' and (storage.foldername(name))[1] = auth.uid()::text;
  delete from auth.users where id = auth.uid();
end $$;
revoke execute on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- ==== PART 4: admin tools ====
create or replace function public.admin_overview() returns json
language plpgsql stable security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  return json_build_object(
    'users', (select count(*) from profiles),
    'businesses', (select count(*) from profiles where account_type = 'business'),
    'seekers', (select count(*) from profiles where available and account_type = 'person'),
    'open_listings', (select count(*) from listings where status = 'open' and date >= current_date),
    'applications', (select count(*) from applications),
    'messages_7d', (select count(*) from messages where created_at > now() - interval '7 days'),
    'new_users_7d', (select count(*) from profiles where created_at > now() - interval '7 days'),
    'open_reports', (select count(*) from reports where status = 'open'));
end $$;

create or replace function public.admin_reports() returns json
language plpgsql stable security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  return coalesce((select json_agg(r order by r.created_at desc) from (
    select rp.id, rp.reason, rp.status, rp.created_at, rp.listing_id, rp.reported_user_id,
      l.title as listing_title, l.status as listing_status, l.owner_id as listing_owner,
      rr.name as reporter_name, ru.name as reported_name, ru.banned as reported_banned
    from reports rp
    left join listings l on l.id = rp.listing_id
    left join profiles rr on rr.id = rp.reporter_id
    left join profiles ru on ru.id = coalesce(rp.reported_user_id, l.owner_id)
    order by rp.created_at desc limit 200) r), '[]'::json);
end $$;

-- ==== PART 5: admin actions ====
create or replace function public.admin_resolve_report(r uuid, s text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  update reports set status = s where id = r;
end $$;

create or replace function public.admin_set_listing_status(l uuid, s text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  update listings set status = s where id = l;
end $$;

create or replace function public.admin_set_verified(u uuid, v boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  update profiles set verified = v where id = u;
end $$;

create or replace function public.admin_set_banned(u uuid, v boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Not allowed'; end if;
  if u = auth.uid() then raise exception 'Cannot ban yourself'; end if;
  update profiles set banned = v where id = u;
  if v then update listings set status = 'closed' where owner_id = u and status = 'open'; end if;
end $$;

-- ==== PART 6: make the owner an admin (change the email if needed) ====
update public.profiles set is_admin = true
where id = (select id from auth.users where email = 'alitekincelik@gmail.com');
