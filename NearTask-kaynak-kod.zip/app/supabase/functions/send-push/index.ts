// Sends a phone notification for every new row in public.notifications.
// Setup is described in README.md ("Telefon bildirimleri").
import webpush from "npm:web-push@3.6.7";
import { createClient } from "npm:@supabase/supabase-js@2";

const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
webpush.setVapidDetails(Deno.env.get("VAPID_SUBJECT") || "mailto:hello@example.com", Deno.env.get("VAPID_PUBLIC_KEY")!, Deno.env.get("VAPID_PRIVATE_KEY")!);

Deno.serve(async (req) => {
  if (req.headers.get("x-webhook-secret") !== Deno.env.get("WEBHOOK_SECRET")) return new Response("forbidden", { status: 403 });
  const { record } = await req.json();
  if (!record?.user_id) return new Response("ignored");
  const { data: subs } = await sb.from("push_subscriptions").select("endpoint, subscription").eq("user_id", record.user_id);
  const payload = JSON.stringify({ title: record.title, body: record.body, link: record.link });
  await Promise.all((subs || []).map(async (s) => {
    try {
      await webpush.sendNotification(s.subscription, payload);
    } catch (e: any) {
      if (e?.statusCode === 404 || e?.statusCode === 410) await sb.from("push_subscriptions").delete().eq("endpoint", s.endpoint);
    }
  }));
  return new Response("ok");
});
