// Builds NearTask into a single self-contained dist/index.html (plus public/ files),
// the same shape as the version served on GitHub Pages.
// Usage: node scripts/build-single.mjs   (reads .env if present)
// Supabase JS is loaded from the jsDelivr CDN at runtime, so only react, react-dom
// and esbuild are needed locally.
import { build } from "esbuild";
import { readFileSync, writeFileSync, mkdirSync, cpSync, existsSync, rmSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const out = join(root, "dist");
const SUPABASE_CDN = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm";

function readEnv() {
  const env = {};
  // .env.production holds the public live settings; a local .env overrides it.
  for (const name of [".env.production", ".env"]) {
    const file = join(root, name);
    if (!existsSync(file)) continue;
    for (const line of readFileSync(file, "utf8").split(/\r?\n/)) {
      const m = line.match(/^\s*(VITE_[A-Z0-9_]+)\s*=\s*(.*)\s*$/);
      if (m) env[m[1]] = m[2].replace(/^["']|["']$/g, "");
    }
  }
  for (const k of Object.keys(process.env)) if (k.startsWith("VITE_")) env[k] = process.env[k];
  return env;
}

const env = readEnv();
const supabaseCdn = {
  name: "supabase-cdn",
  setup(b) {
    b.onResolve({ filter: /^@supabase\/supabase-js$/ }, () => ({ path: SUPABASE_CDN, external: true }));
  },
};

const result = await build({
  entryPoints: [join(root, "src/main.tsx")],
  bundle: true,
  format: "esm",
  splitting: false,
  minify: true,
  write: false,
  outdir: out,
  target: ["es2020", "safari15"],
  jsx: "automatic",
  loader: { ".svg": "text" },
  define: {
    "import.meta.env": JSON.stringify(env),
    "process.env.NODE_ENV": '"production"',
  },
  nodePaths: process.env.NT_NODE_PATH ? [process.env.NT_NODE_PATH] : [],
  plugins: [supabaseCdn],
  logLevel: "warning",
});

const js = result.outputFiles.find((f) => f.path.endsWith(".js")).text;
const css = result.outputFiles.find((f) => f.path.endsWith(".css"))?.text ?? "";

let html = readFileSync(join(root, "index.html"), "utf8");
html = html
  .replace(/<script type="module" src="[^"]*"><\/script>/, () => `<script type="module">${js.replace(/<\/script/g, "<\\/script")}</script>`)
  .replace("</head>", () => `<style>${css}</style>\n</head>`);

if (existsSync(out)) rmSync(out, { recursive: true });
mkdirSync(out, { recursive: true });
cpSync(join(root, "public"), out, { recursive: true });
writeFileSync(join(out, "index.html"), html);
console.log(`dist/index.html ${(html.length / 1024).toFixed(0)} KB · mode: ${env.VITE_SUPABASE_URL ? "live" : "demo"}`);
