# NearTask

Keynsham, Bristol ve Bath çevresinde vardiyalı iş ve ev hizmeti ilanları sunan mobil uygulama (PWA).

## Özellikler
- E-posta + şifre ile giriş, kayıtta "işletme / kişi" seçimi, şifre sıfırlama
- İş ve hizmet ilanları: fotoğraf, tarih/saat, ücret, gizli adres
- Arama ve filtreler: tür, gün, kategori, sıralama
- Başvuru ve teklif: bekliyor → kabul / ret / geri çekme
- Gerçek zamanlı mesajlaşma ve okunmamış mesaj rozeti
- Tam adres sadece kabul edilen kişiye görünür (veritabanı seviyesinde korunur)
- Puan ve yorum: sadece kabul edilmiş iki taraf birbirini puanlayabilir
- Favoriler, paylaşma, ilan bildirme (moderasyon)
- **Bildirimler:** uygulama içi bildirim merkezi ve telefon bildirimleri (yeni mesaj, başvuru, kabul, davet, yorum, arama uyarısı)
- **Çalışan profilleri:** "İş arıyorum" durumu, beceriler, müsait günler; işletmeler çalışanları bulup vardiyaya davet eder
- **İşletme paneli:** görüntülenme, başvuru, alınan kişi; ilan kopyalama, haftalık tekrar, birden fazla kişi alma (kontenjan dolunca ilan otomatik kapanır)
- **Harita ve yakınlık:** ilanlar haritada, "en yakın" sıralaması, kayıtlı arama uyarıları ("Haber ver")
- **Ana sayfa sayaçları:** iş arayan kişi, kayıtlı işletme ve açık ilan sayısı
- **Mağaza gereksinimleri:** hesap silme, kullanıcı engelleme ve bildirme, küfür filtresi, kullanım şartları onayı, Gizlilik Politikası ve Kullanım Şartları sayfaları (Artwin Ltd)
- **Yönetici paneli:** istatistikler, bildirilen içerikler, ilan kapatma, kullanıcı askıya alma, işletme doğrulama
- İlk açılışta hoş geldin ekranları, profil fotoğrafı / logo
- Arayüz yalnızca İngilizce, açık / koyu tema
- Telefona uygulama gibi yüklenebilir, temel çevrimdışı destek

Supabase anahtarları girilmezse uygulama **demo modunda** çalışır: örnek ilanlar ve mesajlara cevap veren örnek kişilerle.

---

## Kurulum (yaklaşık 15 dakika)

### 1. Veritabanı
1. Supabase'te projeni aç → **SQL Editor** → **New query**
2. `supabase/schema.sql` dosyasının tamamını yapıştır → **Run**
3. "Success" görmelisin. Tablolar, güvenlik kuralları ve fotoğraf deposu hazır.

### 2. E-posta ile kod girişi
1. **Authentication → Sign In / Providers → Email** açık olsun.
2. **Authentication → Emails → Magic Link** şablonunu aç. Gövdeye kodu ekle, örneğin:
   ```
   <h2>NearTask giriş kodun</h2>
   <p>Kodun: <b>{{ .Token }}</b></p>
   <p>Bu kodu sen istemediysen bu e-postayı yok sayabilirsin.</p>
   ```
3. **Authentication → URL Configuration → Site URL** kısmına sitenin adresini yaz (4. adımdan sonra).
4. Canlıya çıkmadan önce: **Project Settings → Auth → SMTP** kısmından kendi e-posta servisini bağla (örn. Resend, Postmark). Supabase'in yerleşik e-postası saatte birkaç e-postayla sınırlı.

### 3. Anahtarlar
**Project Settings → API** sayfasından:
- `Project URL`
- `anon public` key

`.env.example` dosyasını `.env` olarak kopyala ve bu iki değeri yaz.
⚠️ `service_role` key'i **asla** bu dosyaya ya da başka bir yere koyma.

### 4. Yayına alma (Vercel, ücretsiz)
1. Bu klasörü GitHub'a yükle.
2. vercel.com → **Add New Project** → repoyu seç.
3. **Environment Variables** kısmına `VITE_SUPABASE_URL` ve `VITE_SUPABASE_ANON_KEY` ekle → **Deploy**.
4. Çıkan adresi Supabase'teki Site URL'ye yaz. İstersen kendi alan adını (örn. neartask.co.uk) bağla.

Bilgisayarında denemek için: `npm install` ve ardından `npm run dev`.

> **Şu anki yayın:** GitHub Pages (alitekincelik-lang.github.io/neartask). Tek dosyalık sürüm Supabase JS'yi CDN'den yükler; Vite ile `npm run build` alırsan `dist/` klasörünü yükleyebilirsin.
>
> **v3 (mağaza + yönetici):** `supabase/v3_store_admin.sql` dosyasını çalıştır (schema.sql'in sonuna da eklendi). Son satır, alitekincelik@gmail.com hesabını yönetici yapar. Şirket bilgileri: `src/company.ts`.

> **Güncelleme:** `schema.sql` daha önce çalıştırdıysan, yeni sürümü yine baştan sona çalıştırman yeterli. Mevcut verilere dokunmaz.

### 5. Telefon bildirimleri (isteğe bağlı, uygulama kapalıyken bildirim için)
Uygulama açıkken bildirimler bu kurulum olmadan da çalışır. Uygulama kapalıyken telefona bildirim gitmesi için:
1. Bilgisayarında bir kez çalıştır: `npx web-push generate-vapid-keys` → bir public, bir private anahtar verir.
2. Vercel'de `VITE_VAPID_PUBLIC_KEY` = public anahtar ekle ve yeniden deploy et.
3. Supabase CLI ile fonksiyonu yükle: `supabase functions deploy send-push --no-verify-jwt`
4. Supabase → **Edge Functions → send-push → Secrets**: `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT` (mailto:senin@adresin) ve rastgele uzun bir `WEBHOOK_SECRET` ekle.
5. Supabase → **Database → Webhooks → Create**: tablo `notifications`, olay `Insert`, tür "Supabase Edge Functions" → `send-push`; HTTP header olarak `x-webhook-secret: <WEBHOOK_SECRET>` ekle.
6. iPhone'da bildirim için uygulamanın önce "Ana ekrana ekle" ile yüklenmesi gerekir (Apple kuralı).

### 6. Harita
Harita OpenStreetMap karolarını kullanır. Düşük trafikte ücretsizdir. Kullanıcı sayısı artınca MapTiler veya Stadia Maps gibi bir sağlayıcıya geçilmeli (`src/map.tsx` içindeki adres değişir).

### 7. Moderasyon
Bildirilen ilanlar **Table Editor → reports** tablosuna düşer. Sorunlu ilanı **listings** tablosunda `status = closed` yap. Güvenilir işletmeleri **profiles** tablosunda `verified = true` yaparak doğrulanmış rozet verebilirsin.

---

## Canlı siteyi güncelleme (GitHub Pages)
Repo yapısı:
```
/            Canlı site (GitHub Pages buradan yayınlar): index.html, sw.js, manifest, ikonlar
/app         Kaynak kod (bu klasör)
```
Kaynakta değişiklik yaptıktan sonra:
1. `cd app` → `npm install` (ilk seferde)
2. `npm run build:single` → `app/dist/` içinde tek dosyalık site oluşur (Supabase ayarları `.env.production` dosyasından okunur)
3. `app/dist/` içindeki dosyaları repo köküne kopyala ve yükle.

`npm run build` (Vite) de çalışır; çıktısı birkaç dosyadan oluşur ve aynı şekilde köke kopyalanabilir.

## Uygulama mağazaları
- **Hemen:** Site açıkken telefonda "Ana ekrana ekle" ile uygulama gibi yüklenir.
- **Google Play:** pwabuilder.com'a site adresini gir → Android paketi oluşturur (Geliştirici hesabı tek seferlik $25).
- **App Store:** Capacitor ile sarmalanır (Apple Developer yıllık $99). Apple, sadece web sitesini saran uygulamaları reddedebilir. Bu yüzden önce push bildirimleri eklemek mantıklı.

## Yasal kontrol listesi (İngiltere)
- [ ] ICO'ya veri sorumlusu olarak kayıt (ico.org.uk, yıllık yaklaşık £40–60)
- [ ] Gizlilik politikası ve kullanım şartları sayfaları (UK GDPR)
- [ ] Çalışma hakkı kontrolünün ilanı verenin sorumluluğunda olduğunun şartlarda açıkça yazılması
- [ ] Gelir modeline göre şirket ve vergi yapısı (ilan ücreti, komisyon veya abonelik)

## Proje yapısı
```
src/api/demo.ts       Demo modu (tarayıcıda sahte sunucu)
src/api/supabase.ts   Canlı mod (Supabase)
src/screens/          Ekranlar
src/i18n.ts           Tüm arayüz metinleri (İngilizce)
src/styles.css        Tasarım
supabase/schema.sql   Veritabanı ve güvenlik kuralları
```
