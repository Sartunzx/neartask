// Main categories and their "smart request" questions.
// A category is a broad heading; the questions narrow it down (which trade, how big, how often…)
// so posters write clearer requests and helpers can quote accurately.
import type { Application, Category, Kind, Listing, Package, PriceUnit } from "./types";

export interface Question {
  key: string;
  label: string;
  options: string[];
  /** Only ask for these listing kinds (default: both). */
  kinds?: Kind[];
}

export interface CatInfo {
  color: string;
  tint: string;
  /** Short examples shown under the category picker. */
  hint: string;
  questions: Question[];
}

const YESNO = ["Yes", "No"];
const FREQ: Question = { key: "frequency", label: "How often?", options: ["One-off", "Weekly", "Fortnightly", "Monthly"], kinds: ["service"] };
const EXPERIENCE: Question = { key: "experience", label: "Experience", options: ["Not needed", "Preferred", "Required"], kinds: ["job"] };

export const CAT_INFO: Record<Category, CatInfo> = {
  hospitality: {
    color: "#0E7C7B", tint: "#E3F3F2", hint: "Waiting, bar, kitchen, housekeeping, reception",
    questions: [
      { key: "role", label: "Role", options: ["Waiter / waitress", "Bar staff", "Barista", "Chef / cook", "Kitchen porter", "Housekeeping", "Reception", "Other"] },
      EXPERIENCE,
      { key: "uniform", label: "Uniform provided", options: YESNO, kinds: ["job"] },
    ],
  },
  retail: {
    color: "#B7791F", tint: "#FDF3DD", hint: "Shop floor, tills, stock, merchandising",
    questions: [
      { key: "role", label: "Role", options: ["Shop assistant", "Cashier", "Stock / merchandising", "Store supervisor", "Other"] },
      EXPERIENCE,
    ],
  },
  warehouse: {
    color: "#6B4FD8", tint: "#F1ECFE", hint: "Picking, packing, loading, forklift, delivery driving",
    questions: [
      { key: "work", label: "Type of work", options: ["Picking & packing", "Loading / unloading", "Forklift", "Delivery driver", "Other"] },
      { key: "licence", label: "Licence needed", options: ["None", "Car licence", "Van licence", "Forklift licence"] },
    ],
  },
  cleaning: {
    color: "#2F6FDB", tint: "#E8F0FE", hint: "Home, deep, end of tenancy, holiday lets, offices, windows",
    questions: [
      { key: "type", label: "Type of clean", options: ["Regular clean", "Deep clean", "End of tenancy", "Holiday let changeover", "Office / commercial", "Windows", "Carpets / upholstery"] },
      { key: "size", label: "Property size", options: ["Studio", "1 bedroom", "2 bedrooms", "3 bedrooms", "4 bedrooms", "5+ bedrooms", "Not a home"] },
      { key: "supplies", label: "Cleaning supplies", options: ["I provide them", "Cleaner brings them"], kinds: ["service"] },
      FREQ,
    ],
  },
  repairs: {
    color: "#A86A00", tint: "#FFF3D6", hint: "Handyman, plumbing, electrics, painting, tiling, flat-pack",
    questions: [
      { key: "trade", label: "What kind of job?", options: ["Handyman / odd jobs", "Plumbing", "Electrical", "Painting & decorating", "Tiling", "Carpentry / flat-pack", "Plastering", "Roofing", "Other"] },
      { key: "size", label: "How big is the job?", options: ["Small (under 2 hours)", "Half a day", "A full day", "Several days"] },
      { key: "materials", label: "Materials", options: ["I have them", "Tradesperson supplies them", "Not sure"], kinds: ["service"] },
    ],
  },
  garden: {
    color: "#3E8E41", tint: "#E6F4E3", hint: "Lawns, hedges, clearance, planting, fencing",
    questions: [
      { key: "task", label: "What needs doing?", options: ["Lawn mowing", "Hedges & trimming", "Tidy-up / clearance", "Planting", "Fencing", "Other"] },
      { key: "size", label: "Garden size", options: ["Small", "Medium", "Large"] },
      { key: "waste", label: "Waste to take away", options: YESNO, kinds: ["service"] },
      FREQ,
    ],
  },
  moving: {
    color: "#D35F2E", tint: "#FDEDE4", hint: "House moves, single items, man with a van, deliveries",
    questions: [
      { key: "what", label: "What's moving?", options: ["Single item", "A few items", "Studio / 1 bedroom", "2 bedrooms", "3+ bedrooms", "Office", "Delivery / collection"] },
      { key: "access", label: "Access", options: ["Ground floor", "Stairs", "Lift"] },
      { key: "distance", label: "Distance", options: ["Local (under 10 miles)", "10–50 miles", "Over 50 miles"] },
      { key: "loading", label: "Help with loading", options: YESNO, kinds: ["service"] },
    ],
  },
  care: {
    color: "#C2417A", tint: "#FCE8F1", hint: "Shopping, companionship, lifts, home help",
    questions: [
      { key: "help", label: "Kind of help", options: ["Shopping & errands", "Companionship", "Lifts / transport", "Home help", "Personal care", "Other"] },
      { key: "dbs", label: "DBS check needed", options: YESNO },
      FREQ,
    ],
  },
  family: {
    color: "#9C36B5", tint: "#F8F0FC", hint: "Babysitting, school runs, dog walking, pet sitting",
    questions: [
      { key: "help", label: "Kind of help", options: ["Babysitting", "Nanny / childminder", "School run", "Dog walking", "Pet sitting", "Other"] },
      { key: "count", label: "How many children or pets?", options: ["1", "2", "3 or more"] },
      { key: "dbs", label: "DBS check needed", options: YESNO },
      FREQ,
    ],
  },
  lessons: {
    color: "#1971C2", tint: "#E7F5FF", hint: "Tutoring, languages, music, driving, sport",
    questions: [
      { key: "subject", label: "Subject", options: ["Maths", "English", "Science", "Languages", "Music", "Driving", "Sport / fitness", "Computing", "Other"] },
      { key: "level", label: "Level", options: ["Primary", "GCSE", "A-level", "Adult beginner", "Advanced"] },
      { key: "format", label: "Where", options: ["In person", "Online", "Either"] },
      FREQ,
    ],
  },
  beauty: {
    color: "#C2255C", tint: "#FFF0F6", hint: "Hair, nails, make-up, massage, personal training",
    questions: [
      { key: "service", label: "Service", options: ["Hair", "Nails", "Make-up", "Massage", "Personal training", "Other"] },
      { key: "where", label: "Where", options: ["At my home", "At their place", "Either"] },
    ],
  },
  events: {
    color: "#E8590C", tint: "#FFF4E6", hint: "Photography, DJs, catering, event staff, decorations",
    questions: [
      { key: "service", label: "What do you need?", options: ["Photography", "Videography", "DJ / music", "Catering", "Event staff", "Decorations", "Other"] },
      { key: "guests", label: "Number of guests", options: ["Under 20", "20–50", "50–100", "Over 100"] },
    ],
  },
  tech: {
    color: "#364FC7", tint: "#EDF2FF", hint: "Computer help, websites, design, social media, admin",
    questions: [
      { key: "help", label: "Kind of help", options: ["Computer / phone help", "Website", "Graphic design", "Social media", "Admin / data entry", "Other"] },
      { key: "format", label: "Where", options: ["In person", "Remote", "Either"] },
    ],
  },
  auto: {
    color: "#0B7285", tint: "#E3FAFC", hint: "Car wash and valeting, repairs, tyres, vehicle moves",
    questions: [
      { key: "service", label: "What do you need?", options: ["Wash / valet", "Repair / mechanic", "Service / MOT prep", "Tyres", "Vehicle collection", "Other"] },
      { key: "vehicle", label: "Vehicle", options: ["Car", "Van", "Motorbike"] },
    ],
  },
  other: { color: "#677389", tint: "#EDF1F5", hint: "Anything else", questions: [] },
};

/** Categories that are nearly always shifts / jobs rather than home services. */
const JOB_FIRST: Category[] = ["hospitality", "retail", "warehouse"];
export const defaultCategory = (kind: Kind, current: Category): Category =>
  kind === "job" ? (JOB_FIRST.includes(current) ? current : "hospitality") : JOB_FIRST.includes(current) ? "cleaning" : current;

export function questionsFor(c: Category, kind: Kind): Question[] {
  return (CAT_INFO[c]?.questions || []).filter((q) => !q.kinds || q.kinds.includes(kind));
}

/** The answered questions of a listing, in the category's order, as [label, answer] pairs. */
export function answered(c: Category, kind: Kind, details?: Record<string, string> | null): [string, string][] {
  if (!details) return [];
  return questionsFor(c, kind).filter((q) => details[q.key]).map((q) => [q.label, details[q.key]]);
}

/** Keep only answers that belong to the chosen category and kind. */
export function cleanDetails(c: Category, kind: Kind, details?: Record<string, string>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const q of questionsFor(c, kind)) {
    const v = details?.[q.key];
    if (v && q.options.includes(v)) out[q.key] = v;
  }
  return out;
}

const ALCOHOL = /\b(bar|pub|alcohol)\b/i;
/** Jobs and services involving alcohol, childcare or care are for people aged 18 and over. */
export function adultOnly(l: Pick<Listing, "category" | "title" | "description" | "details">): boolean {
  return l.category === "family" || l.category === "care" ||
    (l.category === "hospitality" && (l.details?.role === "Bar staff" || ALCOHOL.test(l.title + " " + (l.description || ""))));
}
export function adultOnlyPackage(p: Pick<Package, "category" | "title" | "description">): boolean {
  return p.category === "family" || p.category === "care" || (p.category === "hospitality" && ALCOHOL.test(p.title + " " + (p.description || "")));
}

export const QUOTE_HOURS = 48;
/** A pending quote is valid for 48 hours after it was given or last updated. */
export function quoteExpired(a: Pick<Application, "price" | "status" | "quoted_at" | "created_at">): boolean {
  if (a.price == null || a.status !== "pending") return false;
  return Date.now() - Date.parse(a.quoted_at || a.created_at) > QUOTE_HOURS * 3600 * 1000;
}

export function fmtPrice(price?: number | null, unit?: PriceUnit | null): string {
  if (price == null) return "";
  const n = Number.isInteger(price) ? String(price) : price.toFixed(2);
  return "£" + n + (unit === "hour" ? "/hr" : "");
}
