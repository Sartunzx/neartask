// Legal details shown in the app, the privacy policy and the terms.
// Fill in the blanks with the details registered at Companies House before publishing to the app stores.
export const COMPANY = {
  name: "Artwin Ltd",
  number: "13371113", // Companies House number
  address: "Office 408, Screenworks, 22 Highbury Grove, London N5 2ER", // Registered office address
  email: "support@artwin.co.uk",
  ico: "", // ICO registration number, once registered
  updated: "26 October 2026",
};
