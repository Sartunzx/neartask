import { useEffect, useState } from "react";
import { useApp } from "../state";
import { CATEGORIES, type Category, type Filters, type Profile } from "../types";
import { Avatar, CatBadge, CatTag, Empty, Icon, ListingCard, Loading, Logo, Stars, TopBar, useLoad, CAT_COLOR } from "../ui";
import { lsGet, lsSet } from "../util";
import { fmtKm, km, myLocation } from "../geo";
import { MiniMap } from "../map";
import { PackageCard } from "./Services";
import type { Key } from "../i18n";

const DEFAULT: Filters = { kind: "all", when: "any", category: "all", q: "", sort: "soon" };
export const getFilters = (): Filters => ({ ...DEFAULT, ...lsGet<Partial<Filters>>("nt_filters", {}) });
export const setFilters = (f: Filters) => lsSet("nt_filters", { ...f, near: undefined });
type Tab = "list" | "map" | "workers";
const setTab = (t: Tab) => lsSet("nt_tab", t);

function Onboarding({ done }: { done(): void }) {
  const { t, go } = useApp();
  const [i, setI] = useState(0);
  const slides: [Key, Key, string, string][] = [
    ["ob1t", "ob1b", "hospitality", "var(--pri)"],
    ["ob2t", "ob2b", "garden", "#B7791F"],
    ["ob3t", "ob3b", "shield", "#2F6FDB"],
  ];
  const [title, body, icon, color] = slides[i];
  const last = i === slides.length - 1;
  return (
    <div className="onboard" role="dialog" aria-modal="true" aria-label="Welcome">
      <button className="link skip" onClick={done}>{t("skip")}</button>
      <div className="ob-art" style={{ background: color }}><Icon name={icon} size={64} /></div>
      <div className="ob-text">
        <h1>{t(title)}</h1>
        <p>{t(body)}</p>
      </div>
      <div className="ob-dots">{slides.map((_, k) => <i key={k} className={k === i ? "on" : ""} />)}</div>
      <button className="btn full" onClick={() => (last ? (done(), go("/login?next=/")) : setI(i + 1))}>{last ? t("getStarted") : t("next")}</button>
      {last && <button className="link center block" onClick={done}>{t("explore")}</button>}
    </div>
  );
}

export function Home() {
  const { api, t, go, me, uid, unreadNotices, onboarded, finishOnboarding } = useApp();
  const { blocked } = useApp();
  const [allRaw] = useLoad(() => api.listListings({ ...DEFAULT, sort: "new" }), [api]);
  const [soonRaw] = useLoad(() => api.listListings({ ...DEFAULT, when: "week", sort: "soon" }), [api]);
  const all = allRaw?.filter((l) => !blocked.has(l.owner_id));
  // Most-requested categories first (open listings and fixed-price services), then the usual order.
  const counts: Record<string, number> = {};
  all?.forEach((l) => { counts[l.category] = (counts[l.category] || 0) + 1; });
  const base = CATEGORIES.filter((c) => c !== "other");
  const catOrder = [...base].sort((a, b) => (counts[b] || 0) - (counts[a] || 0) || base.indexOf(a) - base.indexOf(b));
  const soon = soonRaw?.filter((l) => !blocked.has(l.owner_id));
  const [stats] = useLoad(() => api.stats(), [api]);
  const [pkgs] = useLoad(() => api.listPackages({ category: "all" }).catch(() => []), [api]);
  const [allCats, setAllCats] = useState(false);
  const open = (patch: Partial<Filters>, tab: Tab = "list") => { setFilters({ ...DEFAULT, ...patch }); setTab(tab); go("/explore"); };
  const name = me?.name?.split(" ")[0];
  if (!onboarded && !uid) return <Onboarding done={finishOnboarding} />;
  return (
    <div className="screen">
      <header className="brandbar">
        <Logo />
        <span className="brand">NearTask</span>
        {api.mode === "demo" && <span className="pill">{t("demo")}</span>}
        {uid ? (
          <button className="iconbtn bell" onClick={() => go("/notices")} aria-label={t("notices")}>
            <Icon name="bell" size={22} />{unreadNotices > 0 && <span className="badge">{unreadNotices > 9 ? "9+" : unreadNotices}</span>}
          </button>
        ) : <button className="link" onClick={() => go("/login?next=/")}>{t("signIn")}</button>}
      </header>
      <section className="hero">
        {name ? <h1>{t("hi", { name })}</h1> : <h1>{t("heroA")}<br /><span>{t("heroB")}</span></h1>}
        <p className="mute">{t("region")}</p>
        <button className="searchfake" onClick={() => open({})}><Icon name="search" /> {t("search")}</button>
      </section>

      <div className="stats">
        <button onClick={() => open({}, "workers")}><b>{stats ? stats.seekers.toLocaleString() : "–"}</b><span>{t("statSeekers")}</span></button>
        <button onClick={() => open({ kind: "job" })}><b>{stats ? stats.businesses.toLocaleString() : "–"}</b><span>{t("statBusinesses")}</span></button>
        <button onClick={() => open({})}><b>{stats ? stats.listings.toLocaleString() : "–"}</b><span>{t("statListings")}</span></button>
      </div>

      <div className="duo">
        <button className="duo-a" onClick={() => open({ kind: "job" })}>
          <span className="duo-ic"><Icon name="hospitality" size={22} /></span>
          <b>{t("findWork")}</b><small>{t("findWorkSub")}</small>
        </button>
        <button className="duo-b" onClick={() => open({ kind: "service" })}>
          <span className="duo-ic"><Icon name="garden" size={22} /></span>
          <b>{t("findHelp")}</b><small>{t("findHelpSub")}</small>
        </button>
      </div>
      <button className="maplink" onClick={() => open({}, "map")}><Icon name="map" /> {t("tabMap")} <span className="mute">· {t("region")}</span></button>

      <h2 className="sec">{t("browseCat")}</h2>
      <div className="cats">
        {catOrder.slice(0, allCats ? undefined : 7).map((c) => (
          <button key={c} className="catbtn" onClick={() => open({ category: c })}>
            <span className="catwrap"><CatBadge c={c} size={48} />{(counts[c] || 0) > 0 && <span className="catcount">{counts[c]}</span>}</span>
            <span>{t(("cat." + c) as Key)}</span>
          </button>
        ))}
        <button className="catbtn" onClick={() => setAllCats(!allCats)} aria-expanded={allCats}>
          <span className="catb catmore" style={{ width: 48, height: 48 }}><Icon name={allCats ? "x" : "plus"} size={22} /></span><span>{t(allCats ? "fewerCats" : "moreCats")}</span>
        </button>
      </div>

      {pkgs && pkgs.filter((p) => !blocked.has(p.owner_id) && p.owner_id !== uid).length > 0 && <>
        <div className="sechead"><h2 className="sec">{t("fixedServices")}</h2><button className="link" onClick={() => go("/services")}>{t("seeAll")}</button></div>
        <div className="hscroll">{pkgs.filter((p) => !blocked.has(p.owner_id) && p.owner_id !== uid).slice(0, 6).map((p) => <div className="hs-item" key={p.id}><PackageCard p={p} compact /></div>)}</div>
      </>}
      <div className="sechead"><h2 className="sec">{t("startingSoon")}</h2><button className="link" onClick={() => open({ when: "week" })}>{t("seeAll")}</button></div>
      {!soon ? <Loading /> : <div className="hscroll">{soon.slice(0, 6).map((l) => <div className="hs-item" key={l.id}><ListingCard l={l} compact /></div>)}</div>}

      <div className="sechead"><h2 className="sec">{t("latest")}</h2><button className="link" onClick={() => open({ sort: "new" })}>{t("seeAll")}</button></div>
      {!all ? <Loading /> : all.slice(0, 5).map((l) => <ListingCard key={l.id} l={l} />)}
      {api.mode === "demo" && <p className="note">{t("demoNote")}</p>}
    </div>
  );
}

export function Explore() {
  const { api, t, near, setNear, toast, needAuth, blocked } = useApp();
  const [tab, setT] = useState<Tab>(() => lsGet<Tab>("nt_tab", "list"));
  const [f, setF] = useState<Filters>(getFilters);
  const [q, setQ] = useState(f.q);
  const [sel, setSel] = useState<string | null>(null);
  const [many, setMany] = useState<string[]>([]);
  const [skill, setSkill] = useState<string>("all");
  useEffect(() => { const id = setTimeout(() => setF((x) => ({ ...x, q })), 250); return () => clearTimeout(id); }, [q]);
  useEffect(() => setFilters(f), [f]);
  useEffect(() => setTab(tab), [tab]);
  const [rawList] = useLoad(() => api.listListings({ ...f, near }), [api, f.kind, f.when, f.category, f.q, f.sort, near?.lat, near?.lng]);
  const list = rawList?.filter((l) => !blocked.has(l.owner_id));
  const [workers] = useLoad(() => (tab === "workers" ? api.listWorkers(skill, near) : Promise.resolve([] as Profile[])), [api, tab, skill, near?.lat, near?.lng]);
  const set = (p: Partial<Filters>) => setF((x) => ({ ...x, ...p }));
  const dirty = f.kind !== "all" || f.when !== "any" || f.category !== "all" || f.q;
  const chip = (on: boolean, label: string, fn: () => void, key?: string) => <button key={key || label} className={"chip" + (on ? " on" : "")} aria-pressed={on} onClick={fn}>{label}</button>;
  const locateMe = async () => { const p = await myLocation(); if (p) { setNear(p); set({ sort: "near" }); } else toast(t("locationFail")); };
  const saveAlert = async () => {
    if (needAuth()) return;
    const label = [f.kind !== "all" ? t(f.kind === "job" ? "work" : "services") : "", f.category !== "all" ? t(("cat." + f.category) as Key) : "", f.q].filter(Boolean).join(" · ") || t("allListings");
    await api.saveSearch({ label, kind: f.kind, category: f.category, q: f.q.trim() });
    toast(t("alertSaved"));
  };
  const selected = list?.find((l) => l.id === sel);

  return (
    <div className="screen">
      <div className="stickytop">
        <div className="titlerow">
          <h1 className="pagetitle">{t("explore")}</h1>
          {tab !== "workers" && <button className="alertbtn" onClick={saveAlert}><Icon name="bell" size={17} /> {t("saveAlert")}</button>}
        </div>
        <div className="seg tabs" role="tablist">
          {(["list", "map", "workers"] as Tab[]).map((x) => (
            <button key={x} role="tab" aria-selected={tab === x} className={tab === x ? "on" : ""} onClick={() => setT(x)}>
              <Icon name={x === "list" ? "list" : x === "map" ? "map" : "user"} size={16} /> {t(x === "list" ? "tabListings" : x === "map" ? "tabMap" : "tabWorkers")}
            </button>
          ))}
        </div>
        {tab === "workers" ? (
          <div className="chips">
            {chip(skill === "all", t("all"), () => setSkill("all"))}
            {CATEGORIES.filter((c) => c !== "other").map((c) => chip(skill === c, t(("cat." + c) as Key), () => setSkill(c), c))}
          </div>
        ) : (
          <>
            <label className="searchbox">
              <Icon name="search" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("search")} aria-label={t("search")} type="search" />
            </label>
            <div className="chips">
              {chip(f.kind === "all", t("all"), () => set({ kind: "all" }))}
              {chip(f.kind === "job", t("work"), () => set({ kind: "job" }))}
              {chip(f.kind === "service", t("services"), () => set({ kind: "service" }))}
              <span className="chipsep" />
              {(["any", "today", "tomorrow", "week"] as const).map((w) => chip(f.when === w, t(w === "any" ? "anyDay" : w), () => set({ when: w }), w))}
            </div>
            <div className="row2">
              <select value={f.category} onChange={(e) => set({ category: e.target.value as Category | "all" })} aria-label={t("category")}>
                <option value="all">{t("cat.all")}</option>
                {CATEGORIES.map((c) => <option key={c} value={c}>{t(("cat." + c) as Key)}</option>)}
              </select>
              <select value={f.sort} onChange={(e) => set({ sort: e.target.value as Filters["sort"] })} aria-label="Sort">
                <option value="soon">{t("sortSoon")}</option>
                <option value="new">{t("sortNew")}</option>
                <option value="near">{t("sortNear")}</option>
              </select>
            </div>
          </>
        )}
      </div>

      {(f.sort === "near" || tab === "workers") && !near && (
        <p className="note row"><span className="grow">{t("needLocation")}</span><button className="btn ghost sm" onClick={locateMe}><Icon name="pin" size={16} /> {t("useLocation")}</button></p>
      )}

      {tab === "workers" ? (
        !workers ? <Loading /> : workers.filter((w) => !blocked.has(w.id)).length ? workers.filter((w) => !blocked.has(w.id)).map((w) => <WorkerCard key={w.id} w={w} />) : <Empty icon="user" text={t("noWorkers")} />
      ) : !list ? <Loading /> : tab === "map" ? (
        <>
          <MiniMap center={near || { lat: 51.425, lng: -2.5 }} me={near} selected={sel} onSelect={(id) => { setSel(id); setMany([]); }} onMany={(ids) => { setMany(ids); setSel(null); }} credit={t("mapCredit")}
            pins={list.filter((l) => l.lat != null).map((l) => ({ id: l.id, lat: l.lat!, lng: l.lng!, color: CAT_COLOR[l.category], label: l.pay.replace(/\/hr.*/, "") }))}>
            {selected && <div className="mapcard"><ListingCard l={selected} /></div>}
            {many.length > 0 && <div className="mapcard many">{list.filter((l) => many.includes(l.id)).map((l) => <ListingCard key={l.id} l={l} compact />)}</div>}
          </MiniMap>
          <p className="mute xs">{t("results", { n: list.length })}</p>
        </>
      ) : (
        <>
          <div className="sechead"><span className="mute xs">{t("results", { n: list.length })}</span>
            {dirty && <button className="link" onClick={() => { setQ(""); setF({ ...DEFAULT }); }}>{t("clear")}</button>}</div>
          {list.length ? list.map((l) => <ListingCard key={l.id} l={l} />) : <Empty icon="search" text={t("noResults")} />}
        </>
      )}
    </div>
  );
}

export function WorkerCard({ w }: { w: Profile }) {
  const { t, go, near } = useApp();
  const d = near && w.lat != null ? km(near, { lat: w.lat, lng: w.lng! }) : undefined;
  return (
    <button className="wcard" onClick={() => go("/u/" + w.id)}>
      <Avatar p={w} size={52} />
      <span className="grow">
        <span className="trow"><b className="ellip">{w.name}</b>{w.verified && <span className="vtick"><Icon name="check" size={11} /></span>}<span className="grow" />
          {d !== undefined && <span className="mute xs">{fmtKm(d)}</span>}</span>
        <span className="ellip block wl">{w.headline}</span>
        <span className="lmeta">
          {w.rating_count > 0 && <Stars small value={w.rating_avg} count={w.rating_count} />}
          {w.skills.slice(0, 3).map((s) => <CatTag key={s} c={s} />)}
        </span>
        <span className="days">{["mon", "tue", "wed", "thu", "fri", "sat", "sun"].map((d) => <i key={d} className={w.available_days.includes(d) ? "on" : ""}>{t(("day." + d) as Key).slice(0, 2)}</i>)}</span>
      </span>
    </button>
  );
}

export function Saved() {
  const { api, t, favs } = useApp();
  const [list] = useLoad(async () => {
    const ids = [...favs];
    const ls = await Promise.all(ids.map((id) => api.getListing(id)));
    return ls.filter(Boolean) as NonNullable<(typeof ls)[number]>[];
  }, [api, favs]);
  return (
    <div className="screen">
      <TopBar title={t("savedListings")} backTo="/me" />
      {!list ? <Loading /> : list.length ? list.map((l) => <ListingCard key={l.id} l={l} />) : <Empty icon="heart" text={t("none")} />}
    </div>
  );
}
