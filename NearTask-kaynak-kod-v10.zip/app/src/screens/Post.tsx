import { useEffect, useRef, useState } from "react";
import { useApp } from "../state";
import { CATEGORIES, type Category, type Kind, type ListingInput } from "../types";
import { Icon, Loading, TopBar } from "../ui";
import { today } from "../util";
import { isOffensive } from "../moderation";
import { CAT_INFO, cleanDetails, defaultCategory, fmtPrice, questionsFor } from "../categories";
import { PriceHint } from "./Services";
import type { Key } from "../i18n";

const blank = (): ListingInput => ({
  kind: "job", title: "", category: "hospitality", area: "", date: today(), start_time: null, end_time: null,
  pay: "", description: "", requirements: "", photo_url: null, address: "", positions: 1, details: {},
});
const addDays = (d: string, n: number) => { const x = new Date(d + "T12:00"); x.setDate(x.getDate() + n); return x.toISOString().slice(0, 10); };

export function PostForm({ id, copyFrom }: { id?: string; copyFrom?: string }) {
  const { api, t, go, toast, uid, me, needAuth } = useApp();
  const [f, setF] = useState<ListingInput | null>(id || copyFrom ? null : blank());
  const [repeat, setRepeat] = useState(0);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => { needAuth(); }, [needAuth]);
  useEffect(() => {
    const src = id || copyFrom;
    if (!src || !uid) return;
    (async () => {
      const l = await api.getListing(src);
      if (!l || l.owner_id !== uid) return go("/", true);
      const address = (await api.getAddress(src)) || "";
      setF({ id, positions: l.positions || 1, kind: l.kind, title: l.title, category: l.category, area: l.area, date: l.date, start_time: l.start_time?.slice(0, 5) || null,
        end_time: l.end_time?.slice(0, 5) || null, pay: l.pay, description: l.description, requirements: l.requirements, photo_url: l.photo_url, address, details: { ...(l.details || {}) },
        ...(id ? { status: l.status, date: l.date } : { date: l.date >= today() ? addDays(l.date, 7) : today() }) });
    })();
  }, [api, id, copyFrom, uid, go]);
  useEffect(() => { if (f && !id && !f.area && me?.postcode) setF({ ...f, area: me.postcode }); }, [me]); // eslint-disable-line

  if (!uid) return <div className="screen"><Loading /></div>;
  if (!f) return <div className="screen"><TopBar backTo="/me" /><Loading /></div>;
  const set = (p: Partial<ListingInput>) => { setF({ ...f, ...p }); setErr(""); };

  const pick = async (file?: File) => {
    if (!file) return;
    setBusy(true);
    try { set({ photo_url: await api.uploadPhoto(file) }); } catch { toast(t("error")); } finally { setBusy(false); }
  };
  const submit = async () => {
    const missing = ([["title", f.title.trim().length >= 3], ["area", f.area.trim().length >= 2], ["pay", f.pay.trim()], ["date", f.date]] as const)
      .filter((x) => !x[1]).map((x) => t(x[0] as Key));
    if (missing.length) return setErr(t("required", { f: missing.join(", ") }));
    if (f.date < today()) return setErr(t("pastDate"));
    if (isOffensive([f.title, f.description, f.requirements, f.pay].join(" "))) return setErr(t("offensive"));
    setBusy(true);
    try {
      const base = { ...f, details: cleanDetails(f.category, f.kind, f.details), title: f.title.trim(), area: f.area.trim(), pay: f.pay.trim(), start_time: f.start_time || null, end_time: f.end_time || null, positions: Math.max(1, Math.min(50, f.positions || 1)) };
      const lid = await api.saveListing(base);
      for (let i = 1; !id && i <= repeat; i++) await api.saveListing({ ...base, id: undefined, date: addDays(base.date, 7 * i) });
      toast(id ? t("saved") : repeat ? t("publishedN", { n: repeat + 1 }) : t("published"));
      go(repeat ? "/dashboard" : "/l/" + lid, true);
    } catch { setErr(t("error")); } finally { setBusy(false); }
  };

  const kindBtn = (k: Kind, title: Key, sub: Key, icon: string) => (
    <button type="button" className={"kindbtn" + (f.kind === k ? " on" : "")} aria-pressed={f.kind === k}
      onClick={() => set({ kind: k, category: defaultCategory(k, f.category) })}>
      <Icon name={icon} size={22} /><b>{t(title)}</b><small>{t(sub)}</small>
    </button>
  );

  return (
    <div className="screen form">
      <TopBar title={id ? t("editListing") : t("newListing")} backTo={id ? "/l/" + id : "/"} />
      <fieldset>
        <legend>{t("kindQ")}</legend>
        <div className="duo tight">{kindBtn("job", "kindJob", "kindJobSub", "hospitality")}{kindBtn("service", "kindService", "kindServiceSub", "garden")}</div>
      </fieldset>
      <label>{t("title")}<input value={f.title} onChange={(e) => set({ title: e.target.value })} placeholder={t("titlePh")} maxLength={80} /></label>
      <label>{t("category")}
        <select value={f.category} onChange={(e) => set({ category: e.target.value as Category })}>
          {CATEGORIES.map((c) => <option key={c} value={c}>{t(("cat." + c) as Key)}</option>)}
        </select>
        <small className="help">{CAT_INFO[f.category].hint}</small>
      </label>
      {questionsFor(f.category, f.kind).length > 0 && (
        <div className="smart">
          <span className="lbl">{t("smartTitle")}</span>
          <small className="help">{t("smartHelp")}</small>
          {questionsFor(f.category, f.kind).map((q) => (
            <div className="smartq" key={f.category + q.key}>
              <span className="smartlbl">{q.label}</span>
              <div className="chips wrap">
                {q.options.map((o) => {
                  const on = f.details?.[q.key] === o;
                  return <button type="button" key={o} className={"chip" + (on ? " on" : "")} aria-pressed={on}
                    onClick={() => set({ details: { ...(f.details || {}), [q.key]: on ? "" : o } })}>{o}</button>;
                })}
              </div>
            </div>
          ))}
        </div>
      )}
      <label>{t("date")}<input type="date" value={f.date} min={today()} onChange={(e) => set({ date: e.target.value })} /></label>
      <div className="two">
        <label>{t("start")}<input type="time" value={f.start_time || ""} onChange={(e) => set({ start_time: e.target.value })} /></label>
        <label>{t("end")}<input type="time" value={f.end_time || ""} onChange={(e) => set({ end_time: e.target.value })} /></label>
      </div>
      <div className="two">
        <label>{t("positions")}<input type="number" min={1} max={50} inputMode="numeric" value={f.positions} onChange={(e) => set({ positions: parseInt(e.target.value) || 1 })} /></label>
        {!id ? <label>{t("repeat")}<select value={repeat} onChange={(e) => setRepeat(+e.target.value)}>
          <option value={0}>{t("repeatNo")}</option>{[2, 4, 8].map((n) => <option key={n} value={n - 1}>{t("repeatN", { n })}</option>)}
        </select></label> : <span />}
      </div>
      <label>{f.kind === "job" ? t("pay") : t("budget")}<input value={f.pay} onChange={(e) => set({ pay: e.target.value })} placeholder={t("payPh")} maxLength={30} /></label>
      {f.kind === "service" && <PriceHint category={f.category} onUse={(p, u) => set({ pay: fmtPrice(p, u) })} />}
      <label>{t("area")}<input value={f.area} onChange={(e) => set({ area: e.target.value })} placeholder={t("areaPh")} maxLength={40} /></label>
      <label>{t("addressLabel")}<input value={f.address} onChange={(e) => set({ address: e.target.value })} maxLength={200} autoComplete="street-address" />
        <small className="help"><Icon name="lock" size={12} /> {t("addressHelp")}</small></label>
      <label>{t("description")}<textarea rows={4} value={f.description} onChange={(e) => set({ description: e.target.value })} placeholder={t("descPh")} maxLength={1500} /></label>
      <label>{t("needs")}<input value={f.requirements} onChange={(e) => set({ requirements: e.target.value })} placeholder={t("reqPh")} maxLength={500} /></label>
      <div className="photofield">
        <span className="lbl">{t("photo")}</span>
        {f.photo_url ? (
          <div className="photoprev"><img src={f.photo_url} alt="" /><button type="button" className="btn ghost" onClick={() => set({ photo_url: null })}><Icon name="x" /> {t("removePhoto")}</button></div>
        ) : (
          <button type="button" className="photoadd" onClick={() => fileRef.current?.click()} disabled={busy}><Icon name="camera" size={24} /> {t("addPhoto")}</button>
        )}
        <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => pick(e.target.files?.[0])} />
      </div>
      {err && <p className="err" role="alert">{err}</p>}
      <div className="actionbar"><button className="btn full" onClick={submit} disabled={busy}>{id ? t("saveChanges") : t("publish")}</button></div>
    </div>
  );
}
