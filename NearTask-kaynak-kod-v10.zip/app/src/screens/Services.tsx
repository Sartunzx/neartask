// Fixed-price services ("packages"): helpers publish ready-made offers that customers book in one step,
// plus the shared price guide hint used when posting or pricing.
import { useEffect, useState } from "react";
import { useApp } from "../state";
import { CATEGORIES, type Category, type Package, type PackageInput, type PriceUnit } from "../types";
import { Avatar, CatBadge, Empty, Icon, Loading, Sheet, Stars, TopBar, useLoad } from "../ui";
import { CAT_INFO, adultOnlyPackage, fmtPrice } from "../categories";
import { useAgeGate } from "./AgeGate";
import { fmtKm } from "../geo";
import { today } from "../util";
import { isOffensive } from "../moderation";
import type { Key } from "../i18n";

const DURATIONS = ["30 minutes", "1 hour", "2 hours", "3 hours", "Half a day", "A full day", "1 hour minimum", "2 hour minimum"];

/** "Typical quotes: £90–£110" for a category, from real quotes. Renders nothing until there's enough data. */
export function PriceHint({ category, onUse }: { category: Category; onUse?(price: number, unit: PriceUnit): void }) {
  const { api, t } = useApp();
  const [g] = useLoad(() => api.priceGuide(category).catch(() => null), [api, category]);
  if (!g) return null;
  return (
    <div className="pricehint">
      <Icon name="chart" size={16} />
      <span className="grow">
        <b>{t("guideRange", { lo: fmtPrice(g.low, g.unit), hi: fmtPrice(g.high, g.unit) })}</b>
        <span className="mute xs block">{t("guideBasis", { n: g.n, cat: t(("cat." + category) as Key) })}</span>
      </span>
      {onUse && <button type="button" className="btn ghost sm" onClick={() => onUse(g.mid, g.unit)}>{t("guideUse", { p: fmtPrice(g.mid, g.unit) })}</button>}
    </div>
  );
}

export function PackageCard({ p, compact }: { p: Package; compact?: boolean }) {
  const { go, t } = useApp();
  return (
    <article className={"lcard pkg" + (compact ? " compact" : "")} onClick={() => go("/s/" + p.id)}>
      <CatBadge c={p.category} />
      <div className="lbody">
        <div className="lrow"><h3>{p.title}</h3><span className="pkgprice">{fmtPrice(p.price, p.price_unit)}</span></div>
        <div className="lowner">
          <span className="ellip">{p.owner?.name}</span>
          {p.owner?.verified && <span className="vtick" title={t("verified")}><Icon name="check" size={11} /></span>}
          {p.owner && p.owner.rating_count > 0 && <Stars small value={p.owner.rating_avg} />}
        </div>
        <div className="lmeta">
          {p.duration && <span className="tag ghost"><Icon name="clock" size={12} /> {p.duration}</span>}
          {p.area && <span className="tag ghost ellip">{p.area}{p.distance !== undefined ? " · " + fmtKm(p.distance) : ""}</span>}
          {!p.active && <span className="tag off">{t("paused")}</span>}
        </div>
      </div>
    </article>
  );
}

export function Services() {
  const { api, t, near, blocked } = useApp();
  const [cat, setCat] = useState<Category | "all">("all");
  const [list] = useLoad(() => api.listPackages({ category: cat, near }), [api, cat, near?.lat, near?.lng]);
  const shown = list?.filter((p) => !blocked.has(p.owner_id));
  return (
    <div className="screen">
      <TopBar title={t("fixedServices")} backTo="/" />
      <p className="mute">{t("fixedServicesSub")}</p>
      <div className="chips">
        <button className={"chip" + (cat === "all" ? " on" : "")} onClick={() => setCat("all")}>{t("all")}</button>
        {CATEGORIES.filter((c) => c !== "other").map((c) => (
          <button key={c} className={"chip" + (cat === c ? " on" : "")} aria-pressed={cat === c} onClick={() => setCat(c)}>{t(("cat." + c) as Key)}</button>
        ))}
      </div>
      {!shown ? <Loading /> : shown.length ? shown.map((p) => <PackageCard key={p.id} p={p} />) : <Empty icon="tag" text={t("noServices")} />}
    </div>
  );
}

export function BookService({ id }: { id: string }) {
  const { api, t, go, uid, me, needAuth, toast, blocked } = useApp();
  const [p] = useLoad(() => api.getPackage(id), [api, id]);
  const [date, setDate] = useState(today(1));
  const [time, setTime] = useState("");
  const [address, setAddress] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [delOpen, setDelOpen] = useState(false);
  const [ageSheet, ensureAge] = useAgeGate();
  if (p === undefined) return <div className="screen"><TopBar backTo="/services" /><Loading /></div>;
  if (!p) return <div className="screen"><TopBar backTo="/services" /><Empty icon="tag" text={t("notFound")} /></div>;
  const own = uid === p.owner_id;
  const book = async () => {
    if (needAuth()) return;
    const age = await ensureAge();
    if (!age) return;
    if (age === "16-17" && adultOnlyPackage(p)) return toast(t("adultOnlyToast"));
    if (!date || date < today()) return toast(t("pastDate"));
    if (isOffensive(note)) return toast(t("offensive"));
    setBusy(true);
    try {
      const appId = await api.bookPackage({ packageId: p.id, date, time: time || null, address: address.trim(), note: note.trim() });
      toast(t("bookingSent"));
      go("/chat/" + appId, true);
    } catch { toast(t("error")); } finally { setBusy(false); }
  };
  return (
    <div className="screen detail">
      <TopBar backTo="/services" />
      <div className="dhead">
        <CatBadge c={p.category} size={52} />
        <div><span className="mute xs">{t(("cat." + p.category) as Key)} · {t("fixedPrice")}</span><h1>{p.title}</h1></div>
      </div>
      <div className="facts">
        <div><Icon name="cash" /><span><b className="big">{fmtPrice(p.price, p.price_unit)}</b><br /><span className="mute">{t("fixedPrice")}</span></span></div>
        {p.duration && <div><Icon name="clock" /><span><b>{p.duration}</b><br /><span className="mute">{t("duration")}</span></span></div>}
        {p.area && <div><Icon name="pin" /><span><b>{p.area}</b><br /><span className="mute">{t("servesArea")}</span></span></div>}
      </div>
      {p.description && <><h2 className="sec">{t("details")}</h2><p className="prose">{p.description}</p></>}
      <h2 className="sec">{t("offeredBy")}</h2>
      <button className="owner" onClick={() => go("/u/" + p.owner_id)}>
        <Avatar p={p.owner} size={46} />
        <span className="grow"><b>{p.owner?.name}</b> {p.owner?.verified && <span className="vtag"><Icon name="check" size={12} /> {t("verified")}</span>}<br />
          <Stars value={p.owner?.rating_avg || 0} count={p.owner?.rating_count || 0} small /></span>
        <Icon name="back" size={18} />
      </button>

      {own ? (
        <div className="actionbar">
          <button className="btn" onClick={() => go("/edit-service/" + p.id)}><Icon name="edit" /> {t("edit")}</button>
          <button className="btn ghost sq" onClick={() => setDelOpen(true)} aria-label={t("delete")}><Icon name="trash" /></button>
        </div>
      ) : blocked.has(p.owner_id) ? <p className="banner off">{t("youBlocked")}</p> : (
        <>
          <h2 className="sec">{t("bookTitle")}</h2>
          <div className="two">
            <label>{t("date")}<input type="date" value={date} min={today()} onChange={(e) => setDate(e.target.value)} /></label>
            <label>{t("start")}<input type="time" value={time} onChange={(e) => setTime(e.target.value)} /></label>
          </div>
          <label>{t("addressLabel")}<input value={address} onChange={(e) => setAddress(e.target.value)} maxLength={200} autoComplete="street-address" placeholder={me?.postcode || ""} />
            <small className="help"><Icon name="lock" size={12} /> {t("addressHelp")}</small></label>
          <label>{t("bookNote")}<textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} maxLength={600} placeholder={t("bookNotePh")} /></label>
          <p className="safety"><Icon name="shield" size={18} /> {t("bookSafety")}</p>
          <p className="mute xs">{t("cancelSummary")} <button className="link" onClick={() => go("/terms")}>{t("terms")}</button></p>
          <div className="actionbar"><span className="abpay"><b>{fmtPrice(p.price, p.price_unit)}</b></span>
            <button className="btn" disabled={busy} onClick={book}><Icon name="calendar" /> {t("bookNow")}</button></div>
        </>
      )}
      {ageSheet}
      <Sheet open={delOpen} onClose={() => setDelOpen(false)} title={t("confirmDelete")}>
        <div className="btnrow"><button className="btn ghost" onClick={() => setDelOpen(false)}>{t("cancel")}</button>
          <button className="btn danger" onClick={async () => { setDelOpen(false); await api.deletePackage(p.id); go("/me", true); }}><Icon name="trash" /> {t("delete")}</button></div>
      </Sheet>
    </div>
  );
}

export function ServiceForm({ id }: { id?: string }) {
  const { api, t, go, toast, uid, me, needAuth } = useApp();
  const blank = (): PackageInput => ({ category: "cleaning", title: "", description: "", price: 0, price_unit: "total", duration: "", area: me?.postcode || "", photo_url: null, active: true });
  const [f, setF] = useState<PackageInput | null>(id ? null : blank());
  const [price, setPrice] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => { needAuth(); }, [needAuth]);
  useEffect(() => {
    if (!id || !uid) return;
    api.getPackage(id).then((p) => {
      if (!p || p.owner_id !== uid) return go("/me", true);
      setF({ id: p.id, category: p.category, title: p.title, description: p.description, price: p.price, price_unit: p.price_unit, duration: p.duration, area: p.area, photo_url: p.photo_url, active: p.active });
      setPrice(String(p.price));
    });
  }, [api, id, uid, go]);
  useEffect(() => { if (f && !id && !f.area && me?.postcode) setF({ ...f, area: me.postcode }); }, [me]); // eslint-disable-line
  if (!uid || !f) return <div className="screen"><TopBar backTo="/me" /><Loading /></div>;
  const set = (p: Partial<PackageInput>) => { setF({ ...f, ...p }); setErr(""); };
  const save = async () => {
    const n = Number(price.replace(/[£,\s]/g, ""));
    if (f.title.trim().length < 3) return setErr(t("required", { f: t("title") }));
    if (!(n >= 1 && n < 100000)) return setErr(t("badPrice"));
    if (isOffensive(f.title + " " + f.description)) return setErr(t("offensive"));
    setBusy(true);
    try {
      await api.savePackage({ ...f, title: f.title.trim(), description: f.description.trim(), area: f.area.trim(), price: Math.round(n * 100) / 100 });
      toast(t("saved"));
      go("/me", true);
    } catch { setErr(t("error")); } finally { setBusy(false); }
  };
  return (
    <div className="screen form">
      <TopBar title={id ? t("editService") : t("newService")} backTo="/me" />
      <p className="mute">{t("newServiceSub")}</p>
      <label>{t("category")}
        <select value={f.category} onChange={(e) => set({ category: e.target.value as Category })}>
          {CATEGORIES.map((c) => <option key={c} value={c}>{t(("cat." + c) as Key)}</option>)}
        </select>
        <small className="help">{CAT_INFO[f.category].hint}</small>
      </label>
      <label>{t("title")}<input value={f.title} onChange={(e) => set({ title: e.target.value })} placeholder={t("serviceTitlePh")} maxLength={80} /></label>
      <span className="lbl">{t("yourPrice")}</span>
      <div className="pricerow">
        <span className="pricebox"><b>£</b><input inputMode="decimal" value={price} onChange={(e) => { setPrice(e.target.value); setErr(""); }} placeholder={t("pricePh")} aria-label={t("yourPrice")} maxLength={9} /></span>
        <div className="seg">{(["total", "hour"] as PriceUnit[]).map((u) => <button type="button" key={u} className={f.price_unit === u ? "on" : ""} onClick={() => set({ price_unit: u })}>{t(u === "total" ? "priceTotal" : "priceHour")}</button>)}</div>
      </div>
      <PriceHint category={f.category} onUse={(p, u) => { setPrice(String(p)); set({ price_unit: u }); }} />
      <label>{t("duration")}
        <select value={f.duration} onChange={(e) => set({ duration: e.target.value })}>
          <option value="">{t("choose")}</option>{DURATIONS.map((d) => <option key={d} value={d}>{d}</option>)}
        </select></label>
      <label>{t("servesArea")}<input value={f.area} onChange={(e) => set({ area: e.target.value })} placeholder={t("areaPh")} maxLength={40} /></label>
      <label>{t("whatsIncluded")}<textarea rows={4} value={f.description} onChange={(e) => set({ description: e.target.value })} placeholder={t("includedPh")} maxLength={800} /></label>
      {id && <label className="switch"><input type="checkbox" checked={f.active} onChange={(e) => set({ active: e.target.checked })} />
        <span className="grow"><b>{t("serviceActive")}</b><small className="help">{t("serviceActiveHelp")}</small></span><i /></label>}
      {err && <p className="err" role="alert">{err}</p>}
      <div className="actionbar"><button className="btn full" onClick={save} disabled={busy}>{id ? t("saveChanges") : t("publishService")}</button></div>
    </div>
  );
}
