// Asks people who signed up before age groups existed whether they are 16–17 or 18+,
// once, the first time they make an offer or a booking.
import { useRef, useState, type ReactNode } from "react";
import { useApp } from "../state";
import { Sheet } from "../ui";
import type { AgeGroup } from "../types";

export function useAgeGate(): [ReactNode, () => Promise<AgeGroup | null>] {
  const { api, t, me, refreshMe, toast } = useApp();
  const [open, setOpen] = useState(false);
  const resolver = useRef<(v: AgeGroup | null) => void>();

  const ensure = () => {
    if (!me) return Promise.resolve(null);
    if (me.account_type === "business") return Promise.resolve<AgeGroup>("18+");
    if (me.age_group) return Promise.resolve(me.age_group);
    setOpen(true);
    return new Promise<AgeGroup | null>((res) => { resolver.current = res; });
  };
  const pick = async (age: AgeGroup | null) => {
    setOpen(false);
    if (age && me) {
      try {
        await api.saveProfile({ name: me.name, postcode: me.postcode, bio: me.bio, avatar_url: me.avatar_url, account_type: me.account_type, headline: me.headline || "",
          skills: me.skills || [], available: !!me.available, available_days: me.available_days || [], lat: me.lat, lng: me.lng, age_group: age });
        await refreshMe();
      } catch { toast(t("error")); age = null; }
    }
    resolver.current?.(age);
  };
  const sheet = (
    <Sheet open={open} onClose={() => pick(null)} title={t("ageQ")}>
      <p className="mute">{t("ageWhy")}</p>
      <div className="btnrow pad">
        <button className="btn ghost" onClick={() => pick("16-17")}>{t("age1617")}</button>
        <button className="btn" onClick={() => pick("18+")}>{t("age18")}</button>
      </div>
    </Sheet>
  );
  return [sheet, ensure];
}
