import { useEffect, useState } from "react";
import { fmtKm, km, locate } from "../geo";
import { useApp } from "../state";
import type { Application, PriceUnit } from "../types";
import { adultOnly, answered, fmtPrice, quoteExpired } from "../categories";
import { useAgeGate } from "./AgeGate";
import { PriceHint } from "./Services";
import { Avatar, CatBadge, Empty, Icon, Loading, Sheet, Stars, TopBar, WhenTag, timeRange, useLoad } from "../ui";
import { fmtDate, fmtAgo, type Key } from "../i18n";
import { isOffensive } from "../moderation";

export function ListingView({ id }: { id: string }) {
  const { api, t, lang, uid, go, toast, favs, toggleFav, needAuth, refreshThreads, near, blocked, me } = useApp();
  const [ageSheet, ensureAge] = useAgeGate();
  useEffect(() => { api.viewListing(id).catch(() => {}); }, [api, id]);
  const [data, reload] = useLoad(async () => {
    const l = await api.getListing(id);
    if (!l) return { l: null };
    const [address, mine] = await Promise.all([
      api.getAddress(id),
      uid ? api.myApplications().then((a) => a.find((x) => x.listing_id === id) || null) : Promise.resolve(null),
    ]);
    return { l, address, mine };
  }, [api, id, uid]);
  const [applyOpen, setApplyOpen] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [msg, setMsg] = useState("");
  const [price, setPrice] = useState("");
  const [unit, setUnit] = useState<PriceUnit>("total");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [delOpen, setDelOpen] = useState(false);

  if (!data) return <div className="screen"><TopBar backTo="/explore" /><Loading /></div>;
  const { l, address, mine } = data as { l: any; address: string | null; mine: Application | null };
  if (!l) return <div className="screen"><TopBar backTo="/explore" /><Empty icon="search" text={t("notFound")} /></div>;
  const own = uid === l.owner_id;
  const fav = favs.has(l.id);

  const share = async () => {
    const url = location.href;
    try {
      if (navigator.share) await navigator.share({ title: l.title, text: l.title + " · " + l.pay, url });
      else { await navigator.clipboard.writeText(url); toast(t("linkCopied")); }
    } catch {}
  };
  const startApply = async () => {
    if (needAuth()) return;
    const age = await ensureAge();
    if (!age) return;
    if (age === "16-17" && adultOnly(l)) return toast(t("adultOnlyToast"));
    setMsg(t(l.kind === "job" ? "applyDefaultJob" : "applyDefaultService"));
    setPrice(""); setUnit(/\/\s*h(ou)?r/i.test(l.pay) ? "hour" : "total");
    setApplyOpen(true);
  };
  const sendApply = async () => {
    if (!msg.trim()) return;
    if (isOffensive(msg)) return toast(t("offensive"));
    const p = price.trim() ? Number(price.replace(/[£,\s]/g, "")) : null;
    if (p !== null && !(p >= 1 && p < 100000)) return toast(t("badPrice"));
    setBusy(true);
    try {
      const appId = await api.apply(l.id, msg.trim(), l.kind === "service" && p !== null ? { price: Math.round(p * 100) / 100, unit } : null);
      setApplyOpen(false);
      refreshThreads();
      go("/chat/" + appId);
    } catch { toast(t("error")); } finally { setBusy(false); }
  };
  const sendReport = async () => {
    if (needAuth() || !reason.trim()) return;
    await api.report(l.id, reason.trim()).catch(() => {});
    setReportOpen(false); setReason(""); toast(t("reported"));
  };
  const toggleStatus = async () => { await api.setListingStatus(l.id, l.status === "open" ? "filled" : "open"); reload(); };
  const del = async () => { setDelOpen(false); await api.deleteListing(l.id); go("/me", true); };

  return (
    <div className="screen detail">
      <TopBar backTo="/explore" right={<>
        <button className="iconbtn" onClick={share} aria-label={t("share")}><Icon name="share" /></button>
        {!own && <button className={"iconbtn" + (fav ? " favon" : "")} onClick={() => toggleFav(l.id)} aria-label={t("save")} aria-pressed={fav}><Icon name="heart" fill={fav} /></button>}
      </>} />
      {l.photo_url ? <img className="hero-photo" src={l.photo_url} alt="" /> : null}
      <div className="dhead">
        <CatBadge c={l.category} size={52} />
        <div>
          <span className="mute xs">{t(("cat." + l.category) as Key)} · {l.kind === "job" ? t("job") : t("service")}</span>
          <h1>{l.title}</h1>
        </div>
      </div>
      <div className="facts">
        <div><Icon name="clock" /><span><b>{fmtDate(lang, l.date, { weekday: "long", day: "numeric", month: "long" })}</b><br /><span className="mute">{timeRange(l, t("timeAny"))}</span></span><WhenTag date={l.date} /></div>
        <div><Icon name="cash" /><span><b className="big">{l.pay}</b><br /><span className="mute">{l.kind === "job" ? t("pay") : t("budget")}</span></span></div>
        {(l.positions || 1) > 1 && <div><Icon name="user" /><span><b>{l.positions}</b><br /><span className="mute">{t("positions")}</span></span></div>}
        <div><Icon name="pin" /><span><b>{l.area}</b>{(() => { const p = l.lat != null ? { lat: l.lat, lng: l.lng } : locate(l.area); return near && p ? <span className="mute"> · {t("away", { d: fmtKm(km(near, p)) })}</span> : null; })()}<br />
          {address ? <span className="addr"><Icon name="lock" size={13} /> {address}</span> : <span className="mute">{t("addressHidden")}</span>}</span></div>
      </div>
      {own && l.booked_package && <p className="banner invite"><Icon name="calendar" size={16} /> {t("bookedBanner")}</p>}
      {own && !l.booked_package && l.status === "open" && (l.notified || 0) > 0 && <p className="banner ok"><Icon name="send" size={16} /> {t("sentToN", { n: l.notified })}</p>}
      {!own && me?.age_group === "16-17" && adultOnly(l) && <p className="banner off"><Icon name="shield" size={16} /> {t("adultOnlyBanner")}</p>}
      {l.status !== "open" && <p className="banner off">{l.status === "filled" ? t("filled") : t("closed")}</p>}

      {answered(l.category, l.kind, l.details).length > 0 && <><h2 className="sec">{t("atAGlance")}</h2>
        <dl className="glance">{answered(l.category, l.kind, l.details).map(([k, v]) => <div key={k}><dt>{k}</dt><dd>{v}</dd></div>)}</dl></>}
      {l.description && <><h2 className="sec">{t("details")}</h2><p className="prose">{l.description}</p></>}
      {l.requirements && <><h2 className="sec">{t("needs")}</h2><p className="prose">{l.requirements}</p></>}

      <h2 className="sec">{t("postedBy")}</h2>
      <button className="owner" onClick={() => go("/u/" + l.owner_id)}>
        <Avatar p={l.owner} size={46} />
        <span className="grow">
          <b>{l.owner?.name}</b> {l.owner?.verified && <span className="vtag"><Icon name="check" size={12} /> {t("verified")}</span>}<br />
          <Stars value={l.owner?.rating_avg || 0} count={l.owner?.rating_count || 0} small />
        </span>
        <Icon name="back" size={18} />
      </button>
      <p className="safety"><Icon name="shield" size={18} /> {t("safety")}</p>
      {!own && <button className="link danger" onClick={() => (needAuth() ? null : setReportOpen(true))}><Icon name="flag" size={15} /> {t("report")}</button>}
      <span className="mute xs block">{fmtAgo(lang, l.created_at)}</span>

      <div className="actionbar">
        {own ? (
          <>
            <button className="btn" onClick={() => go("/manage/" + l.id)}>{t("manage")}</button>
            <button className="btn ghost sq" onClick={() => go("/edit/" + l.id)} aria-label={t("edit")}><Icon name="edit" /></button>
            <button className="btn ghost sq" onClick={toggleStatus} aria-label={l.status === "open" ? t("markFilled") : t("reopen")} title={l.status === "open" ? t("markFilled") : t("reopen")}><Icon name={l.status === "open" ? "check" : "plus"} /></button>
            <button className="btn ghost sq" onClick={() => setDelOpen(true)} aria-label={t("delete")}><Icon name="trash" /></button>
          </>
        ) : mine && mine.status !== "withdrawn" ? (
          <>
            <span className={"status st-" + mine.status}>{t(("st." + mine.status) as Key)}{mine.price != null ? " · " + fmtPrice(mine.price, mine.price_unit) : ""}</span>
            <button className="btn" onClick={() => go("/chat/" + mine.id)}><Icon name="chat" /> {t("openChat")}</button>
          </>
        ) : l.status === "open" && !blocked.has(l.owner_id) && !(me?.age_group === "16-17" && adultOnly(l)) ? (
          <><span className="abpay"><b>{l.pay}</b></span><button className="btn" onClick={startApply}>{l.kind === "job" ? t("apply") : t("offer")}</button></>
        ) : null}
      </div>

      {ageSheet}
      <Sheet open={applyOpen} onClose={() => setApplyOpen(false)} title={t("applyTitle")}>
        <p className="mute">{t("applyHint")}</p>
        <textarea rows={5} value={msg} onChange={(e) => setMsg(e.target.value)} maxLength={1000} autoFocus />
        {l.kind === "service" && <>
          <span className="lbl">{t("yourPrice")}</span>
          <div className="pricerow">
            <span className="pricebox"><b>£</b><input inputMode="decimal" value={price} onChange={(e) => setPrice(e.target.value)} placeholder={t("pricePh")} aria-label={t("yourPrice")} maxLength={9} /></span>
            <div className="seg">{(["total", "hour"] as PriceUnit[]).map((u) => <button type="button" key={u} className={unit === u ? "on" : ""} onClick={() => setUnit(u)}>{t(u === "total" ? "priceTotal" : "priceHour")}</button>)}</div>
          </div>
          <small className="help">{t("priceHelp")}</small>
          <PriceHint category={l.category} onUse={(p, u) => { setPrice(String(p)); setUnit(u); }} />
        </>}
        <button className="btn full" disabled={busy || !msg.trim()} onClick={sendApply}><Icon name="send" /> {t("send")}</button>
      </Sheet>
      <Sheet open={delOpen} onClose={() => setDelOpen(false)} title={t("confirmDelete")}>
        <div className="btnrow"><button className="btn ghost" onClick={() => setDelOpen(false)}>{t("cancel")}</button>
          <button className="btn danger" onClick={del}><Icon name="trash" /> {t("delete")}</button></div>
      </Sheet>
      <Sheet open={reportOpen} onClose={() => setReportOpen(false)} title={t("report")}>
        <p className="mute">{t("reportReason")}</p>
        <textarea rows={4} value={reason} onChange={(e) => setReason(e.target.value)} maxLength={500} autoFocus />
        <button className="btn full danger" disabled={!reason.trim()} onClick={sendReport}>{t("send")}</button>
      </Sheet>
    </div>
  );
}

type SortKey = "new" | "price" | "rating";

export function Manage({ id }: { id: string }) {
  const { api, t, go, lang, toast } = useApp();
  const [sort, setSort] = useState<SortKey>("new");
  const [data, reload] = useLoad(async () => ({ l: await api.getListing(id), apps: await api.applicationsFor(id) }), [api, id]);
  if (!data) return <div className="screen"><TopBar backTo={"/l/" + id} /><Loading /></div>;
  const set = async (a: Application, s: "accepted" | "declined") => {
    try { await api.setApplicationStatus(a.id, s); toast(t(("st." + s) as Key)); }
    catch { toast(t("quoteExpiredOwner")); }
    reload();
  };
  const live = data.apps.filter((a) => a.status !== "withdrawn");
  const priced = live.filter((a) => a.price != null && a.status !== "declined" && !quoteExpired(a));
  // Compare like with like: the most common unit among quotes.
  const unit = priced.filter((a) => a.price_unit === "hour").length > priced.length / 2 ? "hour" : "total";
  const same = priced.filter((a) => (a.price_unit || "total") === unit);
  const low = same.length ? Math.min(...same.map((a) => a.price!)) : null;
  const avg = same.length ? Math.round(same.reduce((n, a) => n + a.price!, 0) / same.length) : null;
  const best = live.filter((a) => (a.applicant?.rating_count || 0) > 0).sort((a, b) => (b.applicant!.rating_avg - a.applicant!.rating_avg) || (b.applicant!.rating_count - a.applicant!.rating_count))[0];
  const sorted = [...data.apps].sort((a, b) =>
    sort === "price" ? (a.price ?? Infinity) - (b.price ?? Infinity)
      : sort === "rating" ? (b.applicant?.rating_avg || 0) - (a.applicant?.rating_avg || 0)
      : b.created_at.localeCompare(a.created_at));
  return (
    <div className="screen">
      <TopBar title={t("applicants")} backTo={"/l/" + id} />
      {data.l && <p className="mute">{data.l.title} · {fmtDate(lang, data.l.date)}</p>}
      {priced.length > 0 && (
        <div className="quotesum">
          <Icon name="cash" />
          <span className="grow"><b>{t("quotesN", { n: priced.length })}</b>{low != null && <> · {t("quoteFrom", { p: fmtPrice(low, unit) })} · {t("quoteAvg", { p: fmtPrice(avg, unit) })}</>}</span>
        </div>
      )}
      {data.apps.length > 1 && (
        <div className="seg" role="tablist" aria-label={t("sortBy")}>
          {(["new", "price", "rating"] as SortKey[]).map((k) => (
            <button key={k} role="tab" aria-selected={sort === k} className={sort === k ? "on" : ""} onClick={() => setSort(k)}>
              {t(k === "new" ? "sortNewest" : k === "price" ? "sortPrice" : "sortRating")}
            </button>
          ))}
        </div>
      )}
      {!data.apps.length ? <Empty icon="user" text={t("noApplicants")} /> : sorted.map((a) => (
        <div className={"appcard" + (a.status === "withdrawn" || a.status === "declined" ? " dim" : "")} key={a.id}>
          <button className="owner flat" onClick={() => go("/u/" + a.applicant_id)}>
            <Avatar p={a.applicant} size={44} />
            <span className="grow"><b>{a.applicant?.name}</b><br /><Stars small value={a.applicant?.rating_avg || 0} count={a.applicant?.rating_count || 0} /></span>
            {a.price != null ? <span className="qprice">{fmtPrice(a.price, a.price_unit)}</span> : <span className={"status st-" + a.status}>{t(("st." + a.status) as Key)}</span>}
          </button>
          {(a.price != null || (low != null && a.price === low) || best?.id === a.id) && (
            <div className="qtags">
              {a.price != null && (quoteExpired(a) ? <span className="status sm st-declined">{t("quoteExpired")}</span> : <span className={"status sm st-" + a.status}>{t(("st." + a.status) as Key)}</span>)}
              {low != null && same.length > 1 && a.price === low && (a.price_unit || "total") === unit && a.status !== "declined" && <span className="tag good"><Icon name="cash" size={12} /> {t("lowestPrice")}</span>}
              {best?.id === a.id && live.length > 1 && <span className="tag good"><Icon name="star" size={12} /> {t("topRated")}</span>}
            </div>
          )}
          <p className="quote">“{a.message}”</p>
          {quoteExpired(a) && <p className="mute xs">{t("quoteExpiredOwner")}</p>}
          <div className="btnrow">
            <button className="btn ghost" onClick={() => go("/chat/" + a.id)}><Icon name="chat" /> {t("openChat")}</button>
            {a.status === "pending" && <>
              <button className="btn ghost" onClick={() => set(a, "declined")}>{t("decline")}</button>
              {!quoteExpired(a) && <button className="btn" onClick={() => set(a, "accepted")}><Icon name="check" /> {t("accept")}</button>}
            </>}
          </div>
        </div>
      ))}
    </div>
  );
}
