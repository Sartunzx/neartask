-- =====================================================================
-- v7: phone notifications when the app is closed
-- Run AFTER deploying the send-push Edge Function (verify_jwt off). Safe to re-run.
-- No secrets in this file: the function only sends notifications that already
-- exist in the database, once each (pushed_at).
-- =====================================================================
create extension if not exists pg_net;

alter table public.notifications add column if not exists pushed_at timestamptz;

-- Remove the settings table used by the first draft of v7, if it was created.
drop table if exists private.settings;

create or replace function public.on_notification_push() returns trigger
language plpgsql security definer set search_path = public, extensions as $$
begin
  if not exists (select 1 from push_subscriptions where user_id = new.user_id) then return new; end if;
  perform net.http_post(
    url := 'https://qayxsfanlheldqepegob.supabase.co/functions/v1/send-push',
    headers := jsonb_build_object('Content-Type', 'application/json'),
    body := jsonb_build_object('id', new.id)
  );
  return new;
exception when others then
  return new; -- never block the notification itself
end $$;
revoke execute on function public.on_notification_push() from public, anon, authenticated;

drop trigger if exists notification_push on public.notifications;
create trigger notification_push after insert on public.notifications
  for each row execute function public.on_notification_push();
