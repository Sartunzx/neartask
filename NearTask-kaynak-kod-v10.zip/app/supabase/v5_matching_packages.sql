-- =====================================================================
-- v5: automatic matching, price guide, job completion + NearTask Promise,
--     fixed-price services (packages)
-- Needs v4 first. Safe to re-run. Supabase → SQL Editor → New query → Run.
-- =====================================================================

-- ---------- 1. Automatic matching ----------
-- New requests are sent straight to nearby helpers who picked that category under "What I do".
alter table public.profiles add column if not exists match_alerts boolean not null default true;
grant update (name, postcode, bio, avatar_url, account_type, headline, skills, available, available_days, lat, lng, portfolio, match_alerts)
  on public.profiles to authenticated;

alter table public.listings add column if not exists notified int not null default 0;     -- how many helpers were told
alter table public.listings add column if not exists booked_package uuid;                  -- set when created by booking a package

create or replace function public.km_between(lat1 double precision, lng1 double precision, lat2 double precision, lng2 double precision)
returns double precision language sql immutable as $$
  select 6371 * 2 * asin(sqrt(power(sin(radians(lat2 - lat1) / 2), 2)
    + cos(radians(lat1)) * cos(radians(lat2)) * power(sin(radians(lng2 - lng1) / 2), 2)))
$$;

create or replace function public.on_listing_match() returns trigger
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if new.status <> 'open' or new.booked_package is not null then return new; end if;
  with helpers as (
    select p.id from profiles p
    where p.id <> new.owner_id
      and p.match_alerts and not p.banned
      and new.category = any (p.skills)
      and (new.kind = 'service' or p.available)                -- shifts go to people looking for work
      and not blocked_between(p.id, new.owner_id)
      and (
        (p.lat is not null and new.lat is not null and km_between(p.lat, p.lng, new.lat, new.lng) <= 20)
        or ((p.lat is null or new.lat is null) and p.postcode <> '' and new.area ilike '%' || p.postcode || '%')
      )
      -- skip people who already got a saved-search alert for this listing
      and not exists (select 1 from notifications x where x.user_id = p.id and x.link = '/l/' || new.id)
    order by case when p.lat is not null and new.lat is not null then km_between(p.lat, p.lng, new.lat, new.lng) else 99 end
    limit 100
  ), sent as (
    insert into notifications (user_id, type, title, body, link)
    select h.id, 'match',
      case when new.kind = 'service' then 'New request near you: ' else 'New shift near you: ' end || new.title,
      left(new.area || ' · ' || new.pay, 140), '/l/' || new.id
    from helpers h
    returning 1
  )
  select count(*) into n from sent;
  update listings set notified = n where id = new.id;
  return new;
end $$;
drop trigger if exists listing_match on public.listings;
create trigger listing_match after insert on public.listings for each row execute function public.on_listing_match();

-- Saved-search alerts ignore private bookings.
create or replace function public.on_listing_alert() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.booked_package is not null then return new; end if;
  insert into notifications (user_id, type, title, body, link)
  select distinct s.user_id, 'alert', 'New match: ' || new.title, new.area || ' - ' || new.pay, '/l/' || new.id
  from saved_searches s
  where s.user_id <> new.owner_id
    and (s.kind = 'all' or s.kind = new.kind)
    and (s.category = 'all' or s.category = new.category)
    and (s.q = '' or (new.title || ' ' || new.area || ' ' || new.description) ilike '%' || s.q || '%');
  return new;
end $$;

-- ---------- 2. Price guide ----------
-- Typical quotes for a category over the last year. Needs at least 3 quotes, otherwise returns null.
create or replace function public.price_guide(cat text) returns json
language sql stable security definer set search_path = public as $$
  with q as (
    select a.price, a.price_unit from applications a join listings l on l.id = a.listing_id
    where l.category = cat and a.price is not null and a.created_at > now() - interval '365 days'
  ), u as (
    select price_unit from q group by price_unit order by count(*) desc, price_unit limit 1
  ), s as (
    select q.price from q, u where q.price_unit = u.price_unit
  )
  select case when (select count(*) from s) < 3 then null else json_build_object(
    'n', (select count(*) from s),
    'unit', (select price_unit from u),
    'low', (select round(percentile_cont(0.25) within group (order by price)::numeric) from s),
    'mid', (select round(percentile_cont(0.5) within group (order by price)::numeric) from s),
    'high', (select round(percentile_cont(0.75) within group (order by price)::numeric) from s)) end
$$;
grant execute on function public.price_guide(text) to anon, authenticated;

-- ---------- 3. Job completion + NearTask Promise ----------
alter table public.applications add column if not exists completed_at timestamptz;

-- The person who posted marks an accepted job as done; both sides are asked for a review.
create or replace function public.complete_job(a uuid) returns void
language plpgsql security definer set search_path = public as $$
declare r record;
begin
  select ap.id, ap.applicant_id, ap.status, ap.completed_at, l.owner_id, l.title into r
  from applications ap join listings l on l.id = ap.listing_id where ap.id = a;
  if r.id is null or r.owner_id <> auth.uid() then raise exception 'Not allowed'; end if;
  if r.status <> 'accepted' then raise exception 'Only accepted jobs can be completed'; end if;
  if r.completed_at is not null then return; end if;
  update applications set completed_at = now() where id = a;
  perform notify(r.applicant_id, 'completed', 'Job done: ' || r.title, 'Leave a review to help others choose.', '/chat/' || a);
  perform notify(r.owner_id, 'completed', 'How did it go? ' || r.title, 'Leave a review to help others choose.', '/chat/' || a);
end $$;
revoke execute on function public.complete_job(uuid) from public, anon;
grant execute on function public.complete_job(uuid) to authenticated;

-- Report a problem with a job within 72 hours of it being completed (or of the job date).
create or replace function public.report_job_problem(a uuid, reason text) returns void
language plpgsql security definer set search_path = public as $$
declare r record; since timestamptz;
begin
  select ap.id, ap.applicant_id, ap.status, ap.completed_at, l.id as lid, l.owner_id, l.date into r
  from applications ap join listings l on l.id = ap.listing_id where ap.id = a;
  if r.id is null or auth.uid() not in (r.applicant_id, r.owner_id) then raise exception 'Not allowed'; end if;
  if r.status <> 'accepted' then raise exception 'Only accepted jobs'; end if;
  since := coalesce(r.completed_at, (r.date + 1)::timestamptz);
  if now() > since + interval '72 hours' then raise exception 'The 72-hour window has passed'; end if;
  if char_length(coalesce(reason, '')) not between 5 and 480 then raise exception 'Please describe the problem'; end if;
  insert into reports (reporter_id, listing_id, reported_user_id, reason)
  values (auth.uid(), r.lid, case when auth.uid() = r.owner_id then r.applicant_id else r.owner_id end, '[Job problem] ' || reason);
end $$;
revoke execute on function public.report_job_problem(uuid, text) from public, anon;
grant execute on function public.report_job_problem(uuid, text) to authenticated;

-- Track record counts completed jobs, and accepted jobs whose date has passed.
create or replace function public.profile_stats(u uuid) returns json
language sql stable security definer set search_path = public as $$
  with mine as (
    select a.id from applications a join listings l on l.id = a.listing_id
    where a.applicant_id = u or l.owner_id = u
  ), m as (
    select x.sender_id, x.created_at,
      lag(x.sender_id) over (partition by x.application_id order by x.created_at) as prev_sender,
      lag(x.created_at) over (partition by x.application_id order by x.created_at) as prev_at
    from messages x
    where x.application_id in (select id from mine) and x.created_at > now() - interval '120 days'
  )
  select json_build_object(
    'jobs_done', (select count(*) from applications a join listings l on l.id = a.listing_id
                  where a.applicant_id = u and a.status = 'accepted' and (a.completed_at is not null or l.date <= current_date)),
    'hires', (select count(*) from applications a join listings l on l.id = a.listing_id
              where l.owner_id = u and a.status = 'accepted'),
    'reply_minutes', (select round(percentile_cont(0.5) within group (order by extract(epoch from (m.created_at - m.prev_at)) / 60))::int
                      from m where m.sender_id = u and m.prev_sender is not null and m.prev_sender <> u))
$$;

-- Bookings get their own notification text.
create or replace function public.on_application_notify() returns trigger
language plpgsql security definer set search_path = public as $$
declare l record; who text; q text;
begin
  select owner_id, title, booked_package into l from listings where id = new.listing_id;
  q := case when new.price is null then ''
            else ' · £' || trim(to_char(new.price, 'FM99999.00')) || case when new.price_unit = 'hour' then '/hr' else '' end end;
  q := replace(q, '.00', '');
  if tg_op = 'INSERT' then
    if new.status = 'invited' and l.booked_package is not null then
      select name into who from profiles where id = l.owner_id;
      perform notify(new.applicant_id, 'booking', 'New booking' || q || ': ' || coalesce(nullif(who, ''), 'someone'), l.title, '/chat/' || new.id);
    elsif new.status = 'invited' then
      select name into who from profiles where id = l.owner_id;
      perform notify(new.applicant_id, 'invite', coalesce(nullif(who, ''), 'Someone') || ' invited you', l.title, '/chat/' || new.id);
    else
      select name into who from profiles where id = new.applicant_id;
      perform notify(l.owner_id, 'application',
        case when new.price is null then 'New applicant: ' else 'New quote: ' end || coalesce(nullif(who, ''), 'someone') || q,
        l.title, '/manage/' || new.listing_id);
    end if;
  elsif new.status <> old.status then
    if new.status in ('accepted','declined') and old.status = 'pending' then
      perform notify(new.applicant_id, new.status, initcap(new.status) || ': ' || l.title, '', '/chat/' || new.id);
    elsif old.status = 'invited' and new.status in ('accepted','declined') then
      select name into who from profiles where id = new.applicant_id;
      perform notify(l.owner_id, new.status, coalesce(nullif(who, ''), 'Worker') || ' ' || new.status || ' your invite', l.title, '/chat/' || new.id);
    end if;
  end if;
  return new;
end $$;

-- ---------- 4. Fixed-price services (packages) ----------
create table if not exists public.packages (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  category text not null check (category in ('hospitality','retail','warehouse','cleaning','repairs','garden','moving','care',
    'family','lessons','beauty','events','tech','auto','other')),
  title text not null check (char_length(title) between 3 and 80),
  description text not null default '' check (char_length(description) <= 800),
  price numeric(10,2) not null check (price >= 1 and price < 100000),
  price_unit text not null default 'total' check (price_unit in ('total','hour')),
  duration text not null default '' check (char_length(duration) <= 30),
  area text not null default '' check (char_length(area) <= 40),
  photo_url text,
  active boolean not null default true,
  lat double precision,
  lng double precision,
  created_at timestamptz not null default now()
);
create index if not exists packages_active on public.packages (category) where active;
alter table public.packages enable row level security;
drop policy if exists "packages read" on public.packages;
create policy "packages read" on public.packages for select using (active or owner_id = auth.uid());
drop policy if exists "packages insert" on public.packages;
create policy "packages insert" on public.packages for insert with check (owner_id = auth.uid() and not public.is_banned());
drop policy if exists "packages update" on public.packages;
create policy "packages update" on public.packages for update using (owner_id = auth.uid()) with check (owner_id = auth.uid());
drop policy if exists "packages delete" on public.packages;
create policy "packages delete" on public.packages for delete using (owner_id = auth.uid());
grant select on public.packages to anon, authenticated;
grant insert, update, delete on public.packages to authenticated;

-- Booking a package creates a private request and invites the provider at the package price.
-- Done in one step so the booking is consistent; the provider then accepts in the chat.
create or replace function public.book_package(pkg uuid, d date, t time, addr text, note text) returns uuid
language plpgsql security definer set search_path = public as $$
declare p record; lid uuid; aid uuid; msg text; payt text;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if is_banned() then raise exception 'Not allowed'; end if;
  select * into p from packages where id = pkg and active;
  if p.id is null then raise exception 'This service is no longer available'; end if;
  if p.owner_id = auth.uid() then raise exception 'You cannot book your own service'; end if;
  if blocked_between(p.owner_id, auth.uid()) then raise exception 'Not allowed'; end if;
  if d is null or d < current_date then raise exception 'Pick a date from today'; end if;
  payt := '£' || replace(trim(to_char(p.price, 'FM99999.00')), '.00', '') || case when p.price_unit = 'hour' then '/hr' else '' end;
  insert into listings (owner_id, kind, title, category, area, date, start_time, pay, description, positions, lat, lng, booked_package)
  values (auth.uid(), 'service', p.title, p.category,
    coalesce(nullif((select postcode from profiles where id = auth.uid()), ''), nullif(p.area, ''), 'Local'),
    d, t, payt, left(coalesce(note, ''), 1500), 1, p.lat, p.lng, p.id)
  returning id into lid;
  insert into listing_private (listing_id, address) values (lid, left(coalesce(addr, ''), 200));
  msg := 'Booking request: ' || p.title || ' (' || payt || ') on ' || to_char(d, 'Dy DD Mon') ||
    coalesce(' at ' || to_char(t, 'HH24:MI'), '') || case when coalesce(note, '') <> '' then E'\n' || left(note, 600) else '' end;
  insert into applications (listing_id, applicant_id, status, message, price, price_unit)
  values (lid, p.owner_id, 'invited', left(msg, 1000), p.price, p.price_unit) returning id into aid;
  insert into messages (application_id, sender_id, body) values (aid, auth.uid(), left(msg, 2000));
  return aid;
end $$;
revoke execute on function public.book_package(uuid, date, time, text, text) from public, anon;
grant execute on function public.book_package(uuid, date, time, text, text) to authenticated;
