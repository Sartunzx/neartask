// Sends a phone notification for a new row in public.notifications.
// Called by the database trigger in supabase/v7_push.sql with { id } only.
// No shared secret is needed: the function reads the notification itself with the
// service role key and sends it at most once (pushed_at), so a caller cannot
// make it send anything that is not already a real, fresh notification.
import webpush from "npm:web-push@3.6.7";
import { createClient } from "npm:@supabase/supabase-js@2";

// Only one secret is required: VAPID_PRIVATE_KEY. The public key and subject are not secret.
const PUBLIC_KEY = "BCy_cYEKcanzitR-C7AQBOKGqqyqytQryOY_36Er36BGPcAbX6vHHZYvc7mw9DTB8Z2dVMYP__pMc2Zy7LK3XVI";
const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
let ready = false;

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("method not allowed", { status: 405 });
  if (!ready) {
    const priv = (Deno.env.get("VAPID_PRIVATE_KEY") || "").trim();
    if (!priv) { console.error("VAPID_PRIVATE_KEY secret is missing"); return new Response("not configured", { status: 503 }); }
    webpush.setVapidDetails((Deno.env.get("VAPID_SUBJECT") || "mailto:hello@artwin.co.uk").trim(), (Deno.env.get("VAPID_PUBLIC_KEY") || PUBLIC_KEY).trim(), priv);
    ready = true;
  }
  let id: string | undefined;
  try { id = (await req.json())?.id; } catch { /* bad body */ }
  if (!id || !/^[0-9a-f-]{36}$/i.test(id)) return new Response("bad request", { status: 400 });

  // Claim the notification: only unsent ones from the last 10 minutes.
  const since = new Date(Date.now() - 10 * 60 * 1000).toISOString();
  const { data: n } = await sb.from("notifications")
    .update({ pushed_at: new Date().toISOString() })
    .eq("id", id).is("pushed_at", null).gte("created_at", since)
    .select("id, user_id, title, body, link").maybeSingle();
  if (!n) return new Response("ignored");

  const { data: subs } = await sb.from("push_subscriptions").select("endpoint, subscription").eq("user_id", n.user_id);
  // The id is used as the notification tag, so the copy the open app shows replaces it instead of doubling up.
  const payload = JSON.stringify({ id: n.id, title: n.title, body: n.body, link: n.link });
  await Promise.all((subs || []).map(async (s) => {
    try {
      await webpush.sendNotification(s.subscription, payload, { TTL: 60 * 60 * 24 });
    } catch (e: any) {
      console.error("push failed", e?.statusCode, e?.body);
      if (e?.statusCode === 404 || e?.statusCode === 410) await sb.from("push_subscriptions").delete().eq("endpoint", s.endpoint);
    }
  }));
  return new Response("ok");
});
