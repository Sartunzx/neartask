-- =====================================================================
-- v6: 48-hour quotes and protections for users aged 16 and 17
-- Needs v5 first. Safe to re-run. Supabase → SQL Editor → New query → Run.
-- =====================================================================

-- ---------- Age group (asked at sign-up; businesses count as 18+) ----------
alter table public.profiles add column if not exists age_group text;
alter table public.profiles drop constraint if exists profiles_age_group;
alter table public.profiles add constraint profiles_age_group check (age_group is null or age_group in ('16-17','18+'));
grant update (name, postcode, bio, avatar_url, account_type, headline, skills, available, available_days, lat, lng, portfolio, match_alerts, age_group)
  on public.profiles to authenticated;

create or replace function public.is_minor() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select age_group = '16-17' from profiles where id = auth.uid()), false)
$$;

-- Jobs and services involving alcohol, childcare or care are 18+.
create or replace function public.adult_only(l uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from listings x where x.id = l and (
    x.category in ('family','care')
    or (x.category = 'hospitality' and (x.details->>'role' = 'Bar staff' or (x.title || ' ' || x.description) ~* '\m(bar|pub|alcohol)\M'))))
$$;

drop policy if exists "applications insert" on public.applications;
create policy "applications insert" on public.applications for insert with check (
  not public.is_banned()
  and exists (select 1 from public.listings l where l.id = listing_id and l.status = 'open'
    and not public.blocked_between(l.owner_id, applicant_id))
  and not (public.adult_only(listing_id) and coalesce((select age_group from public.profiles where id = applicant_id), '') = '16-17')
  and (
    (applicant_id = auth.uid() and status = 'pending' and not public.is_listing_owner(listing_id))
    or (status = 'invited' and public.is_listing_owner(listing_id) and applicant_id <> auth.uid())
  ));

-- ---------- Quotes are valid for 48 hours ----------
alter table public.applications add column if not exists quoted_at timestamptz;
update public.applications set quoted_at = created_at where price is not null and quoted_at is null;

create or replace function public.stamp_quote() returns trigger
language plpgsql as $$
begin
  if new.price is not null and (tg_op = 'INSERT' or new.price is distinct from old.price or new.price_unit is distinct from old.price_unit) then
    new.quoted_at := now();
  end if;
  if new.price is null then new.quoted_at := null; end if;
  return new;
end $$;
drop trigger if exists application_stamp_quote on public.applications;
create trigger application_stamp_quote before insert or update on public.applications
  for each row execute function public.stamp_quote();

create or replace function public.check_application_update() returns trigger
language plpgsql security definer set search_path = public as $$
declare owner uuid;
begin
  if auth.uid() is null then return new; end if; -- dashboard / admin edits
  select owner_id into owner from listings where id = old.listing_id;
  if new.listing_id <> old.listing_id or new.applicant_id <> old.applicant_id or new.message <> old.message then
    raise exception 'Only the status can change';
  end if;
  if (new.price is distinct from old.price or new.price_unit is distinct from old.price_unit)
     and not (auth.uid() = old.applicant_id and new.status = 'pending') then
    raise exception 'Only the applicant can change their quote';
  end if;
  if auth.uid() = old.applicant_id then
    if old.status = 'invited' and new.status in ('accepted','declined') then return new; end if;
    if old.status in ('pending','declined','withdrawn') and new.status in ('withdrawn','pending') then return new; end if;
  end if;
  if auth.uid() = owner and old.status = 'pending' and new.status = 'accepted'
     and old.price is not null and coalesce(old.quoted_at, old.created_at) < now() - interval '48 hours' then
    raise exception 'This quote has expired. Ask for an updated quote first.';
  end if;
  if auth.uid() = owner and old.status <> 'invited' and new.status in ('accepted','declined','pending') then return new; end if;
  if auth.uid() = owner and old.status = 'invited' and new.status = 'withdrawn' then return new; end if;
  raise exception 'Not allowed';
end $$;

create or replace function public.book_package(pkg uuid, d date, t time, addr text, note text) returns uuid
language plpgsql security definer set search_path = public as $$
declare p record; lid uuid; aid uuid; msg text; payt text;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if is_banned() then raise exception 'Not allowed'; end if;
  select * into p from packages where id = pkg and active;
  if p.id is null then raise exception 'This service is no longer available'; end if;
  if p.owner_id = auth.uid() then raise exception 'You cannot book your own service'; end if;
  if blocked_between(p.owner_id, auth.uid()) then raise exception 'Not allowed'; end if;
  if d is null or d < current_date then raise exception 'Pick a date from today'; end if;
  if is_minor() and (p.category in ('family','care') or (p.category = 'hospitality' and (p.title || ' ' || p.description) ~* '\m(bar|pub|alcohol)\M')) then
    raise exception 'This service is for people aged 18 and over';
  end if;
  payt := '£' || replace(trim(to_char(p.price, 'FM99999.00')), '.00', '') || case when p.price_unit = 'hour' then '/hr' else '' end;
  insert into listings (owner_id, kind, title, category, area, date, start_time, pay, description, positions, lat, lng, booked_package)
  values (auth.uid(), 'service', p.title, p.category,
    coalesce(nullif((select postcode from profiles where id = auth.uid()), ''), nullif(p.area, ''), 'Local'),
    d, t, payt, left(coalesce(note, ''), 1500), 1, p.lat, p.lng, p.id)
  returning id into lid;
  insert into listing_private (listing_id, address) values (lid, left(coalesce(addr, ''), 200));
  msg := 'Booking request: ' || p.title || ' (' || payt || ') on ' || to_char(d, 'Dy DD Mon') ||
    coalesce(' at ' || to_char(t, 'HH24:MI'), '') || case when coalesce(note, '') <> '' then E'\n' || left(note, 600) else '' end;
  insert into applications (listing_id, applicant_id, status, message, price, price_unit)
  values (lid, p.owner_id, 'invited', left(msg, 1000), p.price, p.price_unit) returning id into aid;
  insert into messages (application_id, sender_id, body) values (aid, auth.uid(), left(msg, 2000));
  return aid;
end $$;
revoke execute on function public.book_package(uuid, date, time, text, text) from public, anon;
grant execute on function public.book_package(uuid, date, time, text, text) to authenticated;
